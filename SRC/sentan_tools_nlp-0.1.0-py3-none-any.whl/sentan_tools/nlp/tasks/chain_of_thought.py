from .task_manager import LLMTaskManager
from ..utils.exceptions import ReplyParsingError


class ChainOfThought(LLMTaskManager):

    def _prepare_tasks(self, meta_prompt, input_prompt, **kwargs):
        chain_of_thought_prompt = f"""Below is a user input, that contains a task or question.
Before replying to the input, first give a step-by-step description on how to get to the answer.
After each step give the output of the step. At the end give the final answer. 
The final answer has to be prefixed by "$FinalAnswer:". After the final answer don't write anything else.
Formulate the final answer in the same language as the user input or, if a language is specified in the input, use that.

Output Example
--------------
1.Count the number of attendees.
The attendees are Max and Tom, so 2.
2. Multiply the number of attendees with the ticket costs.
10 dollar times two attendees equals a total cost of 20 dollar.
$FinalAnswer: The total ticket cost is 20 dollars,

User Input
----------
{input_prompt}
"""
        return [(meta_prompt, chain_of_thought_prompt, kwargs)]

    def _get_next_task(self, prev_outputs, count, task_list):
        if prev_outputs:
            return None
        return task_list[0]

    def _parse_reply(self, reply):
        try:
            assert "$FinalAnswer:" in reply, "Reply structure is wrong (Crucial parts missing)."
            parsed_reply = reply[reply.find("$FinalAnswer:") + len("$FinalAnswer:"):]
            parsed_reply = parsed_reply.strip()
            assert parsed_reply, "Faulty reply (no final answer)"
            return parsed_reply.strip()
        except Exception as e:
            raise ReplyParsingError(str(e), reply)

    def _perform_task(self, task):
        reply = self._llm.process_data(task[0], task[1], **task[2])
        return self._parse_reply(reply)

    def __init__(self, llm):
        super().__init__(llm)


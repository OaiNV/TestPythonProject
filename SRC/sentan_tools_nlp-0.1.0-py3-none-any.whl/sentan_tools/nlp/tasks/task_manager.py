from abc import abstractmethod, ABC
from typing import Dict, List

from ..llm.llm_connector import LLMConnector, LLMResponse, LLMResultType


class LLMTaskResponse(LLMResponse):

    def __init__(self, reply, token_usage=None):
        self.__reply = reply
        self.__token_usage = token_usage

    def get_main_response(self) -> str:
        return self.__reply

    def get_response_variants(self) -> List[str]:
        return [self.__reply]

    def get_token_usage(self) -> Dict[str, int]:
        return self.__token_usage or {}

    def get_result_status(self, result_idx=0) -> LLMResultType:
        return LLMResultType.FINISHED


class LLMTaskManager(ABC):

    def __init__(self, llm: LLMConnector):
        self._llm: LLMConnector = llm

    @abstractmethod
    def _prepare_tasks(self, meta_prompt: str, input_prompt: str, **kwargs):
        pass

    @abstractmethod
    def _get_next_task(self, prev_outputs, count, task_list):
        pass

    @abstractmethod
    def _perform_task(self, task):
        pass

    def process_data(self, meta_prompt: str, input_prompt: str, **kwargs) -> LLMTaskResponse:
        task_list = self._prepare_tasks(meta_prompt, input_prompt, **kwargs)
        prev_outputs = []
        iter_count = 0
        while task := self._get_next_task(prev_outputs, iter_count, task_list):
            prev_outputs.append(self._perform_task(task))
            iter_count += 1
        return prev_outputs[-1]

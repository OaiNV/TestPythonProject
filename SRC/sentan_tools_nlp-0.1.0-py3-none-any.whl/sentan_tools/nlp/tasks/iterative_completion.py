from .split_data import SplitDataTask


class IterativeCompletionTask(SplitDataTask):

    def _get_next_task(self, prev_outputs, count, task_list):
        last_output = prev_outputs[-1].result if prev_outputs else "<no progress yet>" 
        if count < len(task_list):
            return task_list[count] + [last_output]
        return None

    def _perform_task(self, task):
        meta_prompt, task_input_prompt, current_split, is_single, _, last_output = task
        split_text = "\n".join(current_split)
        if is_single:
            input_prompt = f"""Below a user input is given. Complete the following task by using the user input below as the input for the task:
{task_input_prompt}

User Input
----------
{split_text}
"""
        else:
            input_prompt = f"""Below a user input and the current progress is given. You are completing a task using a long user input step-by-step by processing a part of the input at a time. The current part of the input and the current progress is given below. 
Create the current output by adding the information of the current part of the input to the current progress, in a way that, at the end, the output of the task regarding the complete input is given as a reply.
Do not talk about any part in specific, make sure that the output sounds as if the complete input was processed at once.
Complete the following task by using the user input below as the current input part for the task:
{task_input_prompt}

Current Progress
----------------
{last_output}

User Input
----------
{split_text}
"""
        return self._llm.process_data(meta_prompt, input_prompt)

    def __init__(self, llm, token_limit=2000):
        super().__init__(llm, token_limit=token_limit)


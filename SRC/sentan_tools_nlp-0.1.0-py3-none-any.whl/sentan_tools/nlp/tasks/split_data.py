import math
from abc import ABC
from typing import Optional, Union, List

import numpy as np

from .task_manager import LLMTaskManager
from ..utils.text_helpers import split_text


def calculate_split_loss(splits, optimal_split_size, llm_connector):
    total_loss = 0
    for split in splits:
        len_split = llm_connector.get_token_num("\n".join(split))
        total_loss += np.square(len_split - optimal_split_size)
    return total_loss


def optimize_splits(splits, optimal_split_size, token_limit, llm_connector):
    items = splits[0]
    current_bucket = 0
    new_splits = [[] for _ in range(len(splits))]
    for item in items:
        current_len = llm_connector.get_token_num("\n".join(new_splits[current_bucket]))
        if current_len >= optimal_split_size or current_len + len(item) > token_limit:
            current_bucket += 1
            current_bucket = min(current_bucket, len(new_splits) - 1)
        new_splits[current_bucket].append(item)
    last_diff = 100000000
    current_diff = calculate_split_loss(new_splits, optimal_split_size, llm_connector)
    while current_diff < last_diff:
        last_diff = current_diff
        for i in range(len(new_splits) - 1, 0, -1):
            split_i = list(new_splits[i])
            split_im1 = list(new_splits[i - 1])
            loss_before = calculate_split_loss([split_i, split_im1], optimal_split_size, llm_connector)
            split_im1 = split_im1 + split_i[:1]
            split_i = split_i[1:]
            loss_after = calculate_split_loss([split_i, split_im1], optimal_split_size, llm_connector)
            # print(i, loss_before, loss_after, len(split_i), len(split_im1))
            # print([(len(split), llm_connector.get_token_num("\n".join(split))) for split in [split_i, split_im1]])
            if loss_after < loss_before:
                new_splits[i-1].append(new_splits[i].pop(0))
        current_diff = calculate_split_loss(new_splits, optimal_split_size, llm_connector)
        # print(current_diff, last_diff)
    return new_splits


class SplitDataTask(LLMTaskManager, ABC):

    def _prepare_tasks(self, meta_prompt: str, input_prompt: str, input_data: Optional[Union[str, List[str]]] = None, **kwargs):
        assert input_data is not None, "Input data is required for iterative completion task."
        text_splits = self._create_speech_splits(input_data, self.token_limit)
        task_list = [[meta_prompt, input_prompt, text, len(text_splits) == 1, kwargs] for text in text_splits]
        return task_list

    def _create_speech_splits(self, input_data: Union[str, List[str]], token_limit: int):
        if isinstance(input_data, str):
            input_data = [input_data]
        prepped_data = []
        for data_item in input_data:
            num_tokens = self._llm.get_token_num(data_item)
            if num_tokens > token_limit:
                num_splits = math.ceil(num_tokens / token_limit)
                prepped_data.extend(split_text(data_item, num_splits=num_splits))
            else:
                prepped_data.append(data_item)
        texts_lengths = [self._llm.get_token_num(text) for text in prepped_data]
        total_length = sum(texts_lengths)
        if total_length <= token_limit:
            return [prepped_data]
        num_splits = math.ceil(total_length / token_limit)
        optimal_split_size = (total_length // num_splits) + 1
        first_split = [[] for _ in range(num_splits)]
        first_split[0] = prepped_data
        return optimize_splits(first_split, optimal_split_size, token_limit, self._llm)

    def __init__(self, llm, token_limit=2000):
        super().__init__(llm)
        self.token_limit = token_limit

from collections import defaultdict
from typing import List, Dict, Optional, Union

from .split_data import SplitDataTask
from ..llm import LLMResponse, LLMResultType


class DataSummaryResponse(LLMResponse):

    def __init__(self, summary_responses: List[LLMResponse]):
        self.__summary_responses = list(summary_responses)

    def get_main_response(self) -> str:
        return "\n".join([response.get_main_response() for response in self.__summary_responses])

    def get_response_variants(self) -> List[str]:
        num_choices = len(self.__summary_responses[0].get_response_variants())
        return ["\n".join([response.variants[i] for response in self.__summary_responses]) for i in range(num_choices)]

    def get_token_usage(self) -> Dict[str, int]:
        overall_token_usage = defaultdict(int)
        for response in self.__summary_responses:
            token_usage = response.get_token_usage()
            for key, value in token_usage.items():
                overall_token_usage[key] += value
        return dict(overall_token_usage)

    def get_result_status(self, result_idx=0) -> LLMResultType:
        part_status_values = [response.get_result_status(result_idx=result_idx).value
                              for response in self.__summary_responses]
        max_priority_status = LLMResultType(max(part_status_values))
        return max_priority_status


class DataSummaryTask(SplitDataTask):
    META_PROMPT = """You are an AI assistant tasked to help the user with tasks.
You are highly skilled at extracting and summarizing important information.
You are experienced at creating compact and complete summaries of texts.
"""

    def _prepare_tasks(self, meta_prompt: str, input_prompt: str, input_data: Optional[Union[str, List[str]]] = None, **kwargs):
        task_list = super()._prepare_tasks(meta_prompt, input_prompt, input_data=input_data, **kwargs)
        task_list.append([None, None, None, None, None])
        return task_list

    def _get_next_task(self, prev_outputs, count, task_list):
        if count < len(task_list):
            return task_list[count] + [prev_outputs]
        return None

    def _perform_task(self, task):
        if task[0] is None:
            return DataSummaryResponse(task[-1])
        meta_prompt, task_input_prompt, current_split, _, _, _ = task
        split_text = "\n".join(current_split)
        input_prompt = f"""Below a user input and summary specifics are given. Summarize the user input below as a reply. Make sure to be precise, but do not skip any important information.
When summarizing, make sure to follow the specifics given below.

Summary Specifics
-----------------
{task_input_prompt}

User Input
----------
{split_text}
"""
        return self._llm.process_data(meta_prompt, input_prompt)

    def __init__(self, llm, token_limit=2000):
        super().__init__(llm, token_limit=token_limit)
import math
from dataclasses import dataclass
from typing import Optional, List


@dataclass
class CodeSnippet:
    content: str
    language: Optional[str] = None


def split_text(text: str, num_splits=None, num_chars=None, overlap=50) -> List[str]:
    assert num_splits or num_chars, "Either num_splits or num_chars must be provided."
    if num_splits:
        num_chars = math.ceil(len(text) / num_splits)
    return [text[max(0, i - overlap):i + num_chars + overlap] for i in range(0, len(text), num_chars)]

import tiktoken


def count_tokens(text, model_name):
    encoding = tiktoken.encoding_for_model(model_name)
    return len(encoding.encode(text))

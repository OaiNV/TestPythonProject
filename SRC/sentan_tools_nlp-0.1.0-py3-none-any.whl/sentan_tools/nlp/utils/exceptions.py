class ReplyParsingError(Exception):
    def __init__(self, msg, reply=""):
        super().__init__(msg)
        self.reply = reply
from dataclasses import dataclass
from typing import Optional, List

from .text_helpers import CodeSnippet


def extract_code_content(markdown_text: str) -> List[CodeSnippet]:
    extracted_snippets = []
    start_index = markdown_text.find("```")
    while start_index >= 0:
        end_index = markdown_text.find("```", start_index + 3)
        if end_index < 0:
            break
        unparsed_contents = markdown_text[start_index+3:end_index]
        first_new_line_pos = unparsed_contents.find("\n")
        if first_new_line_pos < 1:
            snippet = CodeSnippet(unparsed_contents)
        else:
            language, *content_lines = unparsed_contents.split("\n")
            # TODO: Check if the first line is really the language and not content (maybe languages are fixed?)
            snippet = CodeSnippet("\n".join(content_lines).strip(), language=language)
        extracted_snippets.append(snippet)
        start_index = end_index + 3
        start_index = markdown_text.find("```", start_index)
    return extracted_snippets

from .tool import Tool
from sentan_tools.utils.network import search_bing


class BingSearchTool(Tool):

    def __init__(self, api_endpoint: str, api_key: str, num_results=5, language="ja"):
        self.api_endpoint = api_endpoint
        self.api_key = api_key
        self.num_results = num_results
        self.language = language
        super().__init__("Bing Web Search", "Search Engine to search the web for additional information.")

    def process_input(self, tool_input: str) -> str:
        bing_results = search_bing(
            tool_input,
            self.api_endpoint,
            self.api_key,
            num_results=self.num_results,
            language=self.language
        )

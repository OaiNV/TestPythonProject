from typing import Any, Dict, List

import numpy as np
import tiktoken

from .llm_connector import LLMConnector, LLMResponse, LLMResultType
from ..utils.openai_utils import openai_retry_decorator


class OpenAIResponse(LLMResponse):

    def __init__(self, api_response):
        self.__api_response = api_response

    def get_main_response(self) -> str:
        return self.__api_response['choices'][0]["message"]["content"]

    def get_response_variants(self) -> List[str]:
        return [r["message"]["content"] for r in self.__api_response['choices']]

    def get_token_usage(self) -> Dict[str, int]:
        return self.__api_response["usage"]

    def get_result_status(self, result_idx=0) -> LLMResultType:
        num_variants = len(self.__api_response['choices'])
        if result_idx < 0 or result_idx >= num_variants:
            raise ValueError(f"Invalid variant index. "
                             f"Only {num_variants} variants, "
                             f"but index is {result_idx}.")
        finish_reason = self.__api_response['choices'][result_idx]["finish_reason"]
        if finish_reason == "stop":
            return LLMResultType.FINISHED
        elif finish_reason is None:
            return LLMResultType.NOT_YET_FINISHED
        elif finish_reason == "length":
            return LLMResultType.MAX_REACHED
        elif finish_reason == "content_filter":
            return LLMResultType.FLAGGED
        else:
            raise NotImplementedError(f"ResultType for {finish_reason} is not implemented")


class OpenAILLM(LLMConnector):

    def __init__(self, api_url, api_key, model_name, is_chat=False, num_choices=2, temperature=1.0, top_p=1.0):
        import openai
        self.api_url = api_url
        self.api_key = api_key
        self.api_type = openai.api_type
        self.api_version = openai.api_version
        self.model_name = model_name
        self.is_chat = is_chat
        self.num_choices = num_choices
        self.temperature = temperature
        self.top_p = top_p
        self.token_usage = {}

    def _get_invocation_parameters(self, meta_prompt: str, input_prompt: str, **kwargs) -> dict[str, Any]:
        if self.is_chat:
            prompt_dict = {"messages": [{"role": "system", "content": meta_prompt}]}
            for question, answer in kwargs.get("chat_history", []):
                prompt_dict["messages"].extend([
                    {"role": "user", "content": question},
                    {"role": "assistant", "content": answer},
                ])
            prompt_dict["messages"].append({"role": "user", "content": input_prompt})
        else:
            if input_prompt:
                input_prompt_wrapper = "\n\nTarget: " + input_prompt + "\n\nAnswer: "
            else:
                input_prompt_wrapper = ""
            prompt_dict = {
                "prompt": meta_prompt + input_prompt_wrapper,
            }
        return {**prompt_dict, "n": self.num_choices, "temperature": self.temperature, "top_p": self.top_p,
                "engine": self.model_name}

    def _add_token_usage(self, latest_usage):
        if self.token_usage:
            for key, value in latest_usage.items():
                self.token_usage[key] += value
        else:
            self.token_usage = latest_usage.copy()

    async def async_process_data(self, meta_prompt: str, input_prompt: str, **kwargs) -> Any:
        import openai
        openai.api_key = self.api_key
        openai.api_base = self.api_url
        openai.api_type = self.api_type
        openai.api_version = self.api_version
        llm_client = openai.ChatCompletion if self.is_chat else openai.Completion

        @openai_retry_decorator()
        async def execute_model(**kwargs):
            return await llm_client.acreate(**kwargs)

        option_kwargs = self._get_invocation_parameters(meta_prompt, input_prompt, **kwargs)
        response = await execute_model(**option_kwargs)
        self._add_token_usage(response["usage"])
        return OpenAIResponse(response)

    def process_data(self, meta_prompt: str, input_prompt: str, **kwargs) -> Any:
        import openai
        openai.api_key = self.api_key
        openai.api_base = self.api_url
        openai.api_type = self.api_type
        openai.api_version = self.api_version
        llm_client = openai.ChatCompletion if self.is_chat else openai.Completion

        @openai_retry_decorator()
        def execute_model(**kwargs):
            return llm_client.create(**kwargs)

        option_kwargs = self._get_invocation_parameters(meta_prompt, input_prompt, **kwargs)
        response = execute_model(**option_kwargs)
        self._add_token_usage(response["usage"])
        return OpenAIResponse(response)

    def embeddings(self, text: str, **kwargs) -> np.ndarray:
        import openai
        openai.api_key = self.api_key
        openai.api_base = self.api_url
        openai.api_type = self.api_type
        openai.api_version = self.api_version
        llm_client = openai.Embedding

        @openai_retry_decorator()
        def execute_model(**kwargs):
            return llm_client.create(**kwargs)

        response = execute_model(input=text, engine=self.model_name)
        return response["data"][0]["embedding"]

    async def async_embeddings(self, text: str, **kwargs) -> np.ndarray:
        import openai
        openai.api_key = self.api_key
        openai.api_base = self.api_url
        openai.api_type = self.api_type
        openai.api_version = self.api_version
        llm_client = openai.Embedding

        @openai_retry_decorator()
        def execute_model(**kwargs):
            return llm_client.acreate(**kwargs)

        response = execute_model(input=text, engine=self.model_name)
        return response["data"][0]["embedding"]

    def get_token_num(self, input_text: str, **kwargs) -> int:
        encoding = tiktoken.model.encoding_for_model(self.model_name)
        text = input_text.replace("\n", " ")
        return len(encoding.encode(text))

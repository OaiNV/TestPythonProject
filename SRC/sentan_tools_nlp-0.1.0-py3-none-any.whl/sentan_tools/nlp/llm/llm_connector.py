from abc import abstractmethod, ABC
from enum import Enum
from typing import List, Dict

import numpy as np

from ..utils.markdown import extract_code_content
from ..utils.text_helpers import CodeSnippet


class LLMResultType(Enum):
    FINISHED = 0
    NOT_YET_FINISHED = 1
    MAX_REACHED = 2
    FLAGGED = 3


class LLMResponse(ABC):

    @abstractmethod
    def get_main_response(self) -> str:
        pass

    @abstractmethod
    def get_response_variants(self) -> List[str]:
        pass

    @abstractmethod
    def get_token_usage(self) -> Dict[str, int]:
        pass

    @abstractmethod
    def get_result_status(self, result_idx=0) -> LLMResultType:
        pass

    @property
    def result(self):
        return self.get_main_response()

    @property
    def variants(self):
        return self.get_response_variants()

    @property
    def token_usage(self):
        return self.get_token_usage()

    @property
    def result_status(self):
        return self.get_result_status()

    def extract_code_snippets(self, result_idx=0) -> List[CodeSnippet]:
        if not 0 <= result_idx < len(self.variants):
            raise ValueError(f"Invalid variant index {result_idx} (max {len(self.variants)})")
        target_variant = self.variants[result_idx]
        return extract_code_content(target_variant)


class LLMConnector(ABC):

    @abstractmethod
    def process_data(self, meta_prompt: str, input_prompt: str, **kwargs) -> LLMResponse:
        pass

    async def async_process_data(self, meta_prompt: str, input_prompt: str, **kwargs) -> LLMResponse:
        return self.process_data(meta_prompt, input_prompt, **kwargs)

    @abstractmethod
    def embeddings(self, text: str, **kwargs) -> np.ndarray:
        pass

    async def async_embeddings(self, text: str, **kwargs) -> np.ndarray:
        return self.process_data(meta_prompt, input_prompt, **kwargs)

    @abstractmethod
    def get_token_num(self, input_text: str, **kwargs) -> int:
        return 0

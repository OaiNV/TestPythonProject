import tiktoken

from .openai_connector import OpenAILLM

AZURE_OPENAI_API_VERSION = "2024-02-15-preview"


class AzureOpenAILLM(OpenAILLM):

    def __init__(self, api_url, api_key, model_name, is_chat=False, num_choices=1, temperature=0.0, top_p=1.0):
        super().__init__(api_url, api_key, model_name, is_chat=is_chat, num_choices=num_choices, temperature=temperature, top_p=top_p)
        self.api_type = "azure"
        self.api_version = AZURE_OPENAI_API_VERSION

    def get_token_num(self, input_text: str, model_name="gpt-3.5-turbo") -> int:
        encoding = tiktoken.model.encoding_for_model(model_name)
        text = input_text.replace("\n", " ")
        return len(encoding.encode(text))

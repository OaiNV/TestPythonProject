import datetime
from collections import defaultdict
from typing import List

from .agent import Agent, _ActionType, _AgentAction
from ..llm.llm_connector import LLMConnector
from ..assistant_tools.tool import Tool
from ..tasks.task_manager import LLMTaskResponse

_SYSTEM_PROMPT = """Assistant is a large language model trained by OpenAI.

Assistant is designed to be able to assist with a wide range of tasks, from answering simple questions to providing in-depth explanations and discussions on a wide range of topics. As a language model, Assistant is able to generate human-like text based on the input it receives, allowing it to engage in natural-sounding conversations and provide responses that are coherent and relevant to the topic at hand.

Assistant is constantly learning and improving, and its capabilities are constantly evolving. It is able to process and understand large amounts of text, and can use this knowledge to provide accurate and informative responses to a wide range of questions. Additionally, Assistant is able to generate its own text based on the input it receives, allowing it to engage in discussions and provide explanations and descriptions on a wide range of topics.

Assistant is also capable of giving sources for its answers. When assistant uses information from the search tool, it creates footnotes showing the source of the information in the form of the link to the url the information is from.

Overall, Assistant is a powerful system that can help with a wide range of tasks and provide valuable insights and information on a wide range of topics. Whether you need help with a specific question or just want to have a conversation about a particular topic, Assistant is here to assist."""


class QAConversationalAgent(Agent):

    def __init__(self, llm: LLMConnector, tools: list[Tool], with_footnotes=True):
        super().__init__(llm, tools)
        self._with_footnotes = with_footnotes

    def _build_tool_history(self, actions: List[_AgentAction]):
        tool_history = []
        for action in actions:
            tool_history.append(action.tool.name + "\n" + action.input)
            tool_history.append(action.result)
        return tool_history

    def _get_next_task(self, prev_outputs, count, task_list):
        if prev_outputs and prev_outputs[-1].type is _ActionType.ANSWER:
            token_usages = [action.token_usage for action in prev_outputs]
            total_token_usage = defaultdict(int)
            for token_usage in token_usages:
                for key, value in token_usage.items():
                    total_token_usage[key] += value
            prev_outputs[-1] = LLMTaskResponse(prev_outputs[-1].result, token_usage=dict(total_token_usage))
            return False
        tool_history = self._build_tool_history(prev_outputs)
        question, kwargs = task_list
        now = datetime.datetime.now()
        tool_names = [t.name for t in self.tools]
        tool_str = "\n".join([f" - {t.name}: {t.description}" for t in self.tools])
        date_time_str = now.strftime("%d %B, %Y %H:%M")
        footnote_instructions = """
When returning the final answer by using the "Final Answer" action, you format the answer in a way that shows where the information is coming from. When the information is coming from a tool result, you use footnotes as described below.
Footnotes consist of two parts the output identifier from the tool at the end of the answer identified with a unique number, and links the those identifiers in the text by using the id numbers.
Every quotation in the text has to have a footnote with a identifier associated with it. Always write the footnotes with the identifier at the end.
The identifier might be a URL or a title for some text.

Footnote example:
```
Final Answer
The current chancellor[^1] of Germany is Olaf Scholz[^2]. \n\n[^1]: https://en.wikipedia.org/wiki/Chancellor\n[^2]: https://en.wikipedia.org/wiki/Olaf_Scholz
```
"""
        footnote_instructions = footnote_instructions if self._with_footnotes else ""
        format_instructions = f"""RESPONSE FORMAT INSTRUCTIONS
----------------------------

When responding to me, the first line of the response has to be the response type. The response type is either "Final Answer" or one of the following tool names: {tool_names}.
Use the tool name, if you want the human to get additional information via the tools as given in the tool description below.
Use "Final Answer", if you want to respond directly to the human.
Analyze the question and the search results already given to determine, if you have enough information to answer the question, and reply accordingly.

**Option 1: Using a tool**
After the response type line, give the necessary input for the tool to find the information you need and nothing else.
The following example is for a tool named Search, which might be or might not be available.

```
Search  // tool name
search query phrase to get the missing information  // tool input
```

**Option 2: Final Answer**
After the response type line, give the answer to the user's question and nothing else.

```
Final Answer
You should put what you want to return to use here. Use footnotes in this response to refer to search result urls, you used to generate the answer.
```
{footnote_instructions}
Do not give any other output, only the ones mentioned above"""
        input_prompt = f"""TOOLS
------
{tool_str}

{format_instructions}

USER'S INPUT
--------------------
The current date and time is ${date_time_str}, your company is CEC, ltd. Here is the user's input (remember to respond in the format given above, and NOTHING else. Remember to use footnotes when using search results. If possible reply in Japanese language, unless you are asked to translate.):

{question}"""
        if len(tool_history) == 0:
            return _SYSTEM_PROMPT, input_prompt, kwargs
        else:
            first_msg = tool_history.pop(0)
            last_msg = tool_history.pop(-1)
            chat_history = kwargs.get("chat_history", [])
            tool_chat_history = [(tool_history[i], tool_history[i+1]) for i in range(0, len(tool_history), 2)]
            chat_history.append((input_prompt, first_msg))
            chat_history.extend(tool_chat_history)
            kwargs["chat_history"] = chat_history
            return _SYSTEM_PROMPT, last_msg, kwargs

    def _perform_task(self, task):
        meta_prompt, input_prompt, kwargs = task
        reply = self._llm.process_data(meta_prompt, input_prompt, **kwargs)
        print(reply)
        token_usage = reply.token_usage
        reply_lines = reply.result.strip().split("\n")
        action_command = reply_lines[0].strip()
        action_parameter = "\n".join(reply_lines[1:])
        if action_command.lower() == "final answer":
            action = _AgentAction(_ActionType.ANSWER, action_parameter, token_usage=token_usage)
        elif action_command.lower() in [t.name.lower() for t in self.tools]:
            action = _AgentAction(
                _ActionType.TOOL,
                action_parameter,
                [t for t in self.tools if t.name.lower() == action_command][0],
                token_usage=token_usage,
            )
        else:
            action = _AgentAction(
                _ActionType.ANSWER,
                action_command + "\n" + action_parameter,
                token_usage=token_usage,
            )
        action.perform()
        return action

    def _prepare_tasks(self, meta_prompt: str, input_prompt: str, **kwargs):
        return [input_prompt, kwargs]

    def __call__(self, question, **kwargs):
        return self.process_data("", question, **kwargs)

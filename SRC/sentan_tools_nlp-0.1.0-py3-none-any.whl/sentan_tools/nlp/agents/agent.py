from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional, Dict

from ..tasks.task_manager import LLMTaskManager
from ..assistant_tools.tool import Tool


class _ActionType(Enum):
    ANSWER = auto()
    TOOL = auto()


@dataclass
class _AgentAction:
    type: _ActionType
    input: str
    tool: Optional[Tool] = None
    result: Optional[str] = None
    token_usage: Dict[str, int] = field(default_factory=dict)

    def perform(self):
        if self.tool is None:
            self.result = self.input
        else:
            self.result = self.tool.process_input(self.input)
        return self.result


class Agent(LLMTaskManager):

    def __init__(self, llm, tools: list[Tool]):
        super().__init__(llm=llm)
        self.tools = tools

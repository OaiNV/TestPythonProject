import os
from typing import Any, Optional, Union

import javalang
from javalang.ast import Node
from javalang.tree import ClassDeclaration, MethodDeclaration, FieldDeclaration, ConstructorDeclaration, Documented

from .code_parsing import ProgrammingCode, CodeFile, CodeNode, CodeClass, CodeFunction, CodeConstructor, CodeField


class JavaFile(CodeFile):

    def __init__(self, java_file: Union[str, ProgrammingCode]):
        super().__init__(java_file)
        self._java_code_tree = javalang.parse.parse(self._code.get_code())

    def get_top_level_nodes(self):
        return [to_java_object(node, self._code, self) for node in self._java_code_tree.types]

    def print_tree(self):
        print(self._java_code_tree)

    def get_language(self):
        return "Java"


class JavaNode(CodeNode):

    def __init__(self, obj_def: Node, file_code_lines: ProgrammingCode, parent_node):
        self._obj_def = obj_def
        self._parent = parent_node
        self._file_code_lines = file_code_lines
        self._doc_string = obj_def.documentation if isinstance(obj_def, Documented) else None

    @property
    def name(self):
        return self._obj_def.name if hasattr(self._obj_def, "name") else f"Unnamed {type(self._obj_def).__name__}"

    @property
    def position(self):
        return self._obj_def.position

    def get_next_child(self, current_child):
        is_obj = [current_child._obj_def == obj for obj in self._obj_def.body]
        assert True in is_obj
        obj_index = is_obj.index(True)
        if obj_index == len(is_obj) - 1:
            return None
        return self._obj_def.body[obj_index + 1]

    def get_code_lines(self) -> list[str]:
        start_ln = self.position.line
        next_obj = self._parent.get_next_child(self)
        end_ln = next_obj.position.line if next_obj else len(self._file_code_lines) - 1
        return self._file_code_lines.slice(start_ln-1, end_ln-1).get_code_lines()

    def get_code(self) -> str:
        return "".join(self.get_code_lines())

    def get_nodes(self):
        if not hasattr(self._obj_def, "body"):
            return []
        return [to_java_object(obj, self._file_code_lines, self)
                for obj in self._obj_def.body
                if isinstance(obj, (ClassDeclaration, MethodDeclaration, FieldDeclaration, ConstructorDeclaration))]

    def has_doc_string(self):
        return bool(self._doc_string)

    def get_content_indentation_level(self):
        next_written_line = ""
        nwl_index = self._obj_def.lineno - 1
        while not next_written_line.strip():
            nwl_index += 1
            next_written_line = self._file_code_lines.get_line(nwl_index)
        return len(next_written_line) - len(next_written_line.lstrip())

    def set_doc_string(self, doc_string):
        if self.has_doc_string():
            raise ValueError("Cannot overwrite existing docstring")
        self._doc_string = doc_string
        doc_string_lines = doc_string.split("\n")
        num_leading_whitespaces = self.get_content_indentation_level()
        doc_string_lines = [" " * num_leading_whitespaces + line.rstrip() for line in doc_string_lines]
        self._file_code_lines.insert_line(self._obj_def.lineno, "\n".join(doc_string_lines) + "\n")


class JavaClass(JavaNode, CodeClass):

    def __init__(self, class_def: ClassDeclaration, file_code_lines: ProgrammingCode, parent_node):
        super(JavaClass, self).__init__(class_def, file_code_lines, parent_node)

    def get_methods(self):
        return [obj for obj in self.get_nodes() if isinstance(obj, JavaFunction)]


class JavaFunction(JavaNode, CodeFunction):

    def __init__(self, function_def: MethodDeclaration, file_code_lines: ProgrammingCode, parent_node):
        super(JavaFunction, self).__init__(function_def, file_code_lines, parent_node)


class JavaField(JavaNode, CodeField):

    def __init__(self, field_def: FieldDeclaration, file_code_lines: ProgrammingCode, parent_node):
        super(JavaField, self).__init__(field_def, file_code_lines, parent_node)


class JavaConstructor(JavaNode, CodeConstructor):

    def __init__(self, constructor_def: ConstructorDeclaration, file_code_lines: ProgrammingCode, parent_node):
        super(JavaConstructor, self).__init__(constructor_def, file_code_lines, parent_node)


def to_java_object(obj: Node, file_code_lines: ProgrammingCode, parent_node=None):
    if isinstance(obj, ClassDeclaration):
        return JavaClass(obj, file_code_lines, parent_node)
    elif isinstance(obj, MethodDeclaration):
        return JavaFunction(obj, file_code_lines, parent_node)
    elif isinstance(obj, FieldDeclaration):
        return JavaField(obj, file_code_lines, parent_node)
    elif isinstance(obj, ConstructorDeclaration):
        return JavaConstructor(obj, file_code_lines, parent_node)
    else:
        raise NotImplementedError(f"Following statement is not supported: {type(obj).__name__}")


if __name__ == '__main__':
    from code_gen.language_conversion import convert_languages
    from llm_connection.azure_openai_connector import AzureOpenAIConnector
    # print([(node.name, node._obj_def.position) for node in JavaFile("C:\WorkPlace\CodeGenAI\CJYL1207.java").get_top_level_nodes()[0].get_nodes()])
    llm_con = AzureOpenAIConnector(
        os.environ["AZURE_OPENAI_URL"],
        os.environ["AZURE_OPENAI_KEY"],
        "code-chat-1",
        True
    )
    for node in JavaFile("C:\WorkPlace\CodeGenAI\CJYL1207.java").get_top_level_nodes()[0].get_nodes():
        # if not isinstance(node, JavaField):
        #     continue
        print((node.name, node._obj_def.position, node._obj_def.modifiers), ":")
        # input(node.get_code())
        if node.name == 'getSeppenNo':
            code = node.get_code()
            code_cutoff = code[:code.rfind("}") + 1]
            print(code_cutoff)
            print("------------------------")
            ts_code = convert_languages(code_cutoff, "Java", "TypeScript",
                                        "The given function is part of a class "
                                        "that defines a user interface.", llm_con)
            print(ts_code)

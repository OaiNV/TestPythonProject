class AvailabilityError(Exception):
    pass

import ast
from typing import Union, Tuple, Iterable, Optional, List, Type

from .code_parsing import (
    ProgrammingCode,
    CodeFile,
    CodeNode,
    CodeClass,
    CodeFunction,
    AccessModifier
)


class PythonAstManager(ProgrammingCode):

    def __init__(self, prog_code: ProgrammingCode):
        super().__init__(prog_code.get_code_lines(), prog_code.file_path)
        self._python_code_tree = ast.parse(self.get_code())
        self._ast_mapping, self._nodes = self.generate_ast_mapping()

    def generate_ast_mapping(self):
        def generate_ast_mapping_for_node(ast_obj: ast.AST, hierarchy: Iterable[str] = (), current_nodes=None):
            if not isinstance(ast_obj, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Module)):
                return None, None
            obj_name = "__module__" if isinstance(ast_obj, ast.Module) else ast_obj.name
            hierarchy_str = "/".join(hierarchy)
            obj_id = hierarchy_str + "$" + obj_name
            mapping = {"name": obj_name, "ast_obj": ast_obj, "id": obj_id, "sub_nodes": {}}
            if not isinstance(ast_obj, ast.Module):
                current_nodes[obj_id] = to_python_object(obj_id, ast_obj, self)
            for sub_obj in ast_obj.body:
                new_hierarchy = list(hierarchy) + [obj_name]
                sub_name, sub_mapping = generate_ast_mapping_for_node(
                    sub_obj, hierarchy=new_hierarchy, current_nodes=current_nodes
                )
                if not sub_name:
                    continue
                mapping["sub_nodes"][sub_name] = sub_mapping
            return obj_name, mapping

        nodes = {}
        _, ast_map = generate_ast_mapping_for_node(self._python_code_tree, current_nodes=nodes)
        return ast_map, nodes

    def get_top_level_nodes(self):
        return [self._nodes[info["id"]] for info in self._ast_mapping["sub_nodes"].values()]

    def get_node_mapping(self, obj_id):
        tree_info, obj_name = obj_id.split("$")
        tree_info_list = tree_info.split("/")
        current_node = self._ast_mapping
        for node_name in tree_info_list[1:]:
            current_node = current_node["sub_nodes"][node_name]
        current_node = current_node["sub_nodes"][obj_name]
        return current_node

    def get_code_range(self, obj_id: str) -> Tuple[int, int]:
        current_node = self.get_node_mapping(obj_id)
        obj_def = current_node["ast_obj"]
        return obj_def.lineno - 1, obj_def.end_lineno + 1

    def get_child_nodes(self, obj_id):
        current_node = self.get_node_mapping(obj_id)
        return [self._nodes[info["id"]] for info in current_node["sub_nodes"].values()]

    def get_doc_string(self, obj_id: str) -> str:
        current_node = self.get_node_mapping(obj_id)
        obj_def: Union[ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef] = current_node["ast_obj"]
        return ast.get_docstring(obj_def)

    def set_doc_string(self, obj_id: str, new_docstring):
        raise NotImplementedError("")

    def get_all_nodes(self, node_types: Optional[List[Type[CodeNode]]] = None) -> List[Tuple[str, CodeNode]]:
        return [(obj_id, obj) for obj_id, obj in self._nodes.items()
                if not node_types or isinstance(obj, tuple(node_types))]

    def get_parent_of(self, obj_id):
        obj_hierarchy = obj_id.split("$")[0].split("/")
        if len(obj_hierarchy) == 1:
            return None
        parent_id = "$".join(["/".join(obj_hierarchy[:-1]), obj_hierarchy[-1]])
        return self._nodes[parent_id]

    def update_node_code(self, new_code: str, node):
        new_code_lines = new_code.split("\n")
        start, end = self.get_code_range(node.get_id())
        ind_level = node.get_content_indentation_level()
        new_code_lines[0] = ind_level * " " + new_code_lines[0].lstrip()
        inner_indent = len(new_code_lines[0]) - len(new_code_lines[0].lstrip())
        if inner_indent <= ind_level:
            add_indent = ind_level + 4 - inner_indent
            for i in range(1, len(new_code_lines)):
                new_code_lines[i] = add_indent * " " + new_code_lines[i]
        self._lines_of_code = self._lines_of_code[:start] + new_code_lines + self._lines_of_code[end - 1:]
        # for line in self.get_code_lines():
        #     print(line)
        self._python_code_tree = ast.parse(self.get_code())
        self._ast_mapping = self.generate_ast_mapping()[0]


class PythonFile(CodeFile):

    def __init__(self, python_file: Union[str, ProgrammingCode]):
        super().__init__(python_file)
        self._python_ast_manager = PythonAstManager(self._code)

    def get_top_level_nodes(self):
        return self._python_ast_manager.get_top_level_nodes()

    def get_language(self):
        return "Python"

    def get_all_nodes(self, node_types: Optional[List[Type[CodeNode]]] = None) -> List[Tuple[str, CodeNode]]:
        return self._python_ast_manager.get_all_nodes(node_types=node_types)


class PythonNode(CodeNode):

    def __init__(self, obj_id: str, ast_manager: PythonAstManager):
        super().__init__(ast_manager)
        self._obj_id = obj_id

    def _get_code_range(self) -> Tuple[int, int]:
        ast_manager: PythonAstManager = self._code_ref
        return ast_manager.get_code_range(self._obj_id)

    @property
    def name(self):
        return self._obj_id.split("$")[-1]

    @property
    def docstring(self):
        ast_manager: PythonAstManager = self._code_ref
        return bool(ast_manager.get_doc_string(self._obj_id))

    @docstring.setter
    def docstring(self, new_docstring):
        ast_manager: PythonAstManager = self._code_ref
        return ast_manager.set_doc_string(self._obj_id, new_docstring)

    def get_nodes(self):
        ast_manager: PythonAstManager = self._code_ref
        return ast_manager.get_child_nodes(self._obj_id)

    def get_content_indentation_level(self):
        ast_manager: PythonAstManager = self._code_ref
        next_written_line = ""
        for next_written_line in self.get_code_lines():
            if next_written_line.strip():
                break
        return len(next_written_line) - len(next_written_line.lstrip())

    def get_id(self):
        return self._obj_id

    def get_parent(self) -> Optional[CodeNode]:
        ast_manager: PythonAstManager = self._code_ref
        return ast_manager.get_parent_of(self._obj_id)

    # def set_doc_string(self, doc_string):
    #     if self.has_doc_string():
    #         raise ValueError("Cannot overwrite existing docstring")
    #     self._doc_string = doc_string
    #     doc_string_lines = doc_string.split("\n")
    #     num_leading_whitespaces = self.get_content_indentation_level()
    #     doc_string_lines = [" " * num_leading_whitespaces + line.rstrip() for line in doc_string_lines]
    #     self._file_code_lines.insert_line(self._obj_def.lineno, "\n".join(doc_string_lines) + "\n")

    def get_access_modifier(self) -> AccessModifier:
        if self.name.startswith("__"):
            return AccessModifier.PRIVATE
        elif self.name.startswith("_"):
            return AccessModifier.PROTECTED
        else:
            return AccessModifier.PUBLIC

    def change_code(self, new_code):
        ast_manager: PythonAstManager = self._code_ref
        ast_manager.update_node_code(new_code, self)


class PythonClass(PythonNode, CodeClass):

    def __init__(self, obj_id: str, ast_manager: PythonAstManager):
        super(PythonClass, self).__init__(obj_id, ast_manager)

    def get_methods(self):
        return [obj for obj in self.get_nodes() if isinstance(obj, PythonFunction)]


class PythonFunction(PythonNode, CodeFunction):

    def __init__(self, obj_id: str, ast_manager: PythonAstManager):
        super(PythonFunction, self).__init__(obj_id, ast_manager)
        
    def change_code(self, new_code):
        new_code_lines = new_code.split("\n")
        if new_code_lines[0].strip().startswith("def "):
            new_func_name = new_code_lines[0].strip()[4:new_code_lines[0].find("(")].strip()
            assert new_func_name == self.name
        else:
            new_code_lines.insert(0, self.get_code_lines()[0])
        super().change_code("\n".join(new_code_lines))


def to_python_object(obj_id: str, obj: ast.stmt, ast_manager: PythonAstManager):
    if isinstance(obj, ast.ClassDef):
        return PythonClass(obj_id, ast_manager)
    elif isinstance(obj, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return PythonFunction(obj_id, ast_manager)
    else:
        raise NotImplementedError(f"Following statement is not supported: {type(obj).__name__}")

from typing import List

from . import parse_code_file
from .code_parsing import CodeFile, ProgrammingCode, CodeFunction, CodeClass


class CodeBase:

    def __init__(self, code_files: List[CodeFile] = ()):
        self.files = {code_file.file_path: code_file for code_file in code_files}

    def add_code(self, prog_code: ProgrammingCode, file_path: str = None):
        file_path = file_path or prog_code.file_path
        assert file_path not in self.files, "File already exists"
        self.files[file_path] = parse_code_file(file_path, code=prog_code)

    def add_file(self, code_file: CodeFile):
        file_path = code_file.file_path
        assert file_path not in self.files, "File already exists"
        self.files[file_path] = code_file

    def get_node_objects(self, node_types=(CodeFunction, CodeClass)):
        all_nodes = []
        for file_path, file_obj in self.files.items():
            all_nodes.extend([
                (f"{obj_id}@{file_path}", obj)
                for obj_id, obj in file_obj.get_all_nodes(node_types=node_types)
            ])
        return all_nodes

    def get_node_by_name(self, name, node_type=None):
        node_types = (node_type,) if node_type else None
        matching_nodes = [node for node in self.get_node_objects(node_types=node_types) if node.name == name]
        assert len(matching_nodes) > 1, f"More than 1 matches for node with name {name}"
        return matching_nodes[0] if matching_nodes else None


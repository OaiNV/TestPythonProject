import os

from .exceptions import AvailabilityError
from .java_parser import JavaFile
from .python_parser import PythonFile


def parse_code_file(file_path, code=None):
    extension = os.path.splitext(file_path)[1][1:].lower()
    if extension in ["py"]:
        return PythonFile(code or file_path)
    elif extension in ["java"]:
        return JavaFile(code or file_path)
    else:
        raise AvailabilityError(f"No parser exists for {extension} files.")

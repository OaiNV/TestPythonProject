from __future__ import annotations

import os
from abc import abstractmethod, ABC
from enum import Enum, auto
from typing import Any, Optional, Tuple, List, Type


class _EditType(Enum):
    INSERT = auto()


class AccessModifier(Enum):
    PUBLIC = 0
    PROTECTED = 1
    PRIVATE = 2


class ProgrammingCode:

    def __init__(self, lines_of_code: list[Any], file_path: Optional[str]):
        self._lines_of_code = lines_of_code
        self._file_path = file_path
        self._change_history = []
        self._was_backed_up = False

    @property
    def file_path(self):
        return self._file_path

    @classmethod
    def from_file(cls, file_name: str, encoding="utf8"):
        with open(file_name, "r", encoding=encoding) as python_fh:
            return cls(python_fh.read().split("\n"), file_name)

    def insert_line(self, pos, line, correct_idx=True):
        if correct_idx:
            pos = self._correct_idx_with_changes(pos)
        self._lines_of_code.insert(pos, line)
        self._change_history.append((pos, _EditType.INSERT))

    def get_code_lines(self):
        return self._lines_of_code

    def get_code(self):
        return "\n".join(self._lines_of_code)

    def save(self, file_path=None):
        if not file_path:
            if not self._change_history:
                return
            if not self._file_path:
                raise ValueError("PythonCode object has not been created from a file")
            file_path = self._file_path
            if not self._was_backed_up:
                backup_file_path = "_old".join(os.path.splitext(file_path))
                os.rename(file_path, backup_file_path)
                self._was_backed_up = True
        with open(file_path, "w", encoding="utf8") as fh:
            fh.writelines(self._lines_of_code)

    def _correct_idx_with_changes(self, idx):
        for line_info, edit_type in self._change_history:
            if edit_type in [_EditType.INSERT]:
                idx = idx + 1 if idx >= line_info else idx
        return idx

    def slice(self, start, end=-1, correct_indices=True):
        if correct_indices:
            start = self._correct_idx_with_changes(start)
            end = self._correct_idx_with_changes(end)
        if end < 0:
            return ProgrammingCode(self._lines_of_code[start:], None)
        return ProgrammingCode(self._lines_of_code[start:end], None)

    def get_line(self, index, correct_indices=True):
        if correct_indices:
            index = self._correct_idx_with_changes(index)
        return self._lines_of_code[index]

    def __len__(self):
        return len(self._lines_of_code)


class CodeNode(ABC):

    def __init__(self, prog_code: ProgrammingCode):
        self._code_ref = prog_code

    @abstractmethod
    def _get_code_range(self) -> Tuple[int, int]:
        return 0, 0

    def get_code_lines(self) -> list[str]:
        start_line, end_line = self._get_code_range()
        return self._code_ref.slice(start_line, end_line).get_code_lines()

    def get_code(self) -> str:
        return "\n".join(self.get_code_lines())

    @abstractmethod
    def get_access_modifier(self) -> AccessModifier:
        pass

    @abstractmethod
    def get_parent(self, node_id) -> Optional[CodeNode]:
        pass

    @abstractmethod
    def change_code(self, new_code):
        pass


class CodeFile(ABC):

    def __init__(self, code_file):
        self._code = code_file
        if isinstance(self._code, str):
            self._python_code = ProgrammingCode.from_file(self._code)

    @property
    def file_path(self):
        return self._code.file_path

    @abstractmethod
    def get_top_level_nodes(self):
        return []

    def save_file(self, file_path: str = None):
        self._code.save(file_path=file_path)

    def get_code_lines(self):
        return self._code.get_code_lines()

    def get_code(self):
        return self._code.get_code()

    def get_language(self):
        return "unknown"

    @abstractmethod
    def get_all_nodes(self, node_types: Optional[List[Type[CodeNode]]] = None) -> List[Tuple[str, CodeNode]]:
        pass


class CodeClass(ABC):

    @abstractmethod
    def get_methods(self):
        return []

    @abstractmethod
    def get_id(self):
        return ""


class CodeFunction:
    pass


class CodeField:
    pass


class CodeConstructor:
    pass

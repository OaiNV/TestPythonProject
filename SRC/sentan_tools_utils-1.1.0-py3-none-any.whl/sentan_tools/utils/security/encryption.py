import os
import io

import pyAesCrypt

_ENCRYPTION_PASSWORD = os.environ.get("ENCRYPTION_PASSWORD", "")


def encrypt_bytes(raw_bytes, pw=_ENCRYPTION_PASSWORD):
    assert pw, "A password has to be given, either by parameter or environment variable ENCRYPTION_PASSWORD."
    out_stream = io.BytesIO()
    pyAesCrypt.encryptStream(io.BytesIO(raw_bytes), out_stream, pw)
    encrypted_bytes = out_stream.getvalue()
    return encrypted_bytes


def encrypt_text(raw_text: str, pw=_ENCRYPTION_PASSWORD, encoding="utf8"):
    raw_bytes = raw_text.encode(encoding=encoding)
    return encrypt_bytes(raw_bytes, pw=pw)


def decrypt_bytes(encrypted_bytes, pw=_ENCRYPTION_PASSWORD):
    assert pw, "A password has to be given, either by parameter or environment variable ENCRYPTION_PASSWORD."
    out_stream = io.BytesIO()
    pyAesCrypt.decryptStream(io.BytesIO(encrypted_bytes), out_stream, pw)
    decrypted_bytes = out_stream.getvalue()
    return decrypted_bytes


def decrypt_text(encrypted_text, pw=_ENCRYPTION_PASSWORD, encoding="utf8"):
    decrypted_bytes = decrypt_bytes(encrypted_text, pw=pw)
    return decrypted_bytes.decode(encoding=encoding)

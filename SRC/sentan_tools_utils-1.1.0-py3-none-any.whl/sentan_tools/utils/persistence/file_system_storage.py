import glob
import json
import os
import datetime
import pickle
from uuid import uuid4
from io import BytesIO
from typing import Union, Optional

import pandas as pd

from . import StorageFileInfo
from ._exceptions import FileDoesNotExistError
from .storage_system import StorageFileFileInfo, StorageSystem, TableHandler, QueueMessage, QueueHandler, FilterCondition, FilterConditionType
from ..security.encryption import decrypt_bytes, encrypt_bytes


_TABLE_FOLDER = ".tables_"
_QUEUE_FOLDER = ".queues_"


class FileSystemTableHandler(TableHandler):

    def __init__(self, storage_folder: str, name: str) -> None:
        super().__init__(name)
        self.__table_file_path = os.path.join(storage_folder, _TABLE_FOLDER, name + ".pkl")
        os.makedirs(os.path.dirname(self.__table_file_path), exist_ok=True)
        self.__pandas_table: Optional[pd.DataFrame] = None
        self.__current_state_size = None
        self._load_table()

    def _load_table(self) -> pd.DataFrame:
        if not os.path.isfile(self.__table_file_path):
            self.__pandas_table = None
            return
        file_size = os.path.getsize(self.__table_file_path)
        if file_size == self.__current_state_size:
            return
        self.__current_state_size = file_size
        self.__pandas_table = pd.read_pickle(self.__table_file_path)

    def _save_table(self):
        self.__pandas_table.to_pickle(self.__table_file_path)
        self.__current_state_size = os.path.getsize(self.__table_file_path)

    def _prepare_access_conditions(self, where: Union[dict, list[FilterCondition]]) -> pd.Series:
        where_conditions = None
        if isinstance(where, dict):
            for key, value in where.items():
                new_condition = self.__pandas_table[key] == value
                if where_conditions is None:
                    where_conditions = new_condition
                else:
                    where_conditions &= new_condition
        else:
            for condition in where:
                if condition.type is FilterConditionType.EQUAL:
                    new_condition = self.__pandas_table[condition.field] == condition.value
                elif condition.type is FilterConditionType.GREATER_THAN:
                    new_condition = self.__pandas_table[condition.field] > condition.value
                elif condition.type is FilterConditionType.LESS_THAN:
                    new_condition = self.__pandas_table[condition.field] < condition.value
                elif condition.type is FilterConditionType.GREATER_THAN_EQUAL:
                    new_condition = self.__pandas_table[condition.field] >= condition.value
                elif condition.type is FilterConditionType.LESS_THAN_EQUAL:
                    new_condition = self.__pandas_table[condition.field] <= condition.value
                elif condition.type is FilterConditionType.NOT_EQUAL:
                    new_condition = self.__pandas_table[condition.field] != condition.value
                elif condition.type is FilterConditionType.IN:
                    new_condition = self.__pandas_table[condition.field].isin(condition.value)
                elif condition.type is FilterConditionType.NOT_IN:
                    new_condition = ~self.__pandas_table[condition.field].isin(condition.value)
                elif condition.type is FilterConditionType.LIKE:
                    new_condition = self.__pandas_table[condition.field].str.contains(condition.value)
                elif condition.type is FilterConditionType.NOT_LIKE:
                    new_condition = ~self.__pandas_table[condition.field].str.contains(condition.value)
                elif condition.type is FilterConditionType.IS_NULL:
                    new_condition = self.__pandas_table[condition.field].isnull()
                elif condition.type is FilterConditionType.IS_NOT_NULL:
                    new_condition = ~self.__pandas_table[condition.field].isnull()
                elif condition.type is FilterConditionType.BETWEEN:
                    new_condition = (self.__pandas_table[condition.field] >= condition.value[0]) & (self.__pandas_table[condition.field] <= condition.value[1])
                elif condition.type is FilterConditionType.NOT_BETWEEN:
                    new_condition = (self.__pandas_table[condition.field] < condition.value[0]) | (self.__pandas_table[condition.field] > condition.value[1])
                if where_conditions is None:
                    where_conditions = new_condition
                else:
                    where_conditions &= new_condition
        return where_conditions

    def get_table_entities(self, where: Union[dict, list[FilterCondition]]={}) -> list[dict]:
        self._load_table()
        if self.__pandas_table is None:
            return []
        where_conditions = self._prepare_access_conditions(where)
        if not any(where_conditions):
            return []
        filtered_df = self.__pandas_table[where_conditions]
        df_dict = filtered_df.to_dict()
        columns_names = list(df_dict.keys())
        return [{col: df_dict[col][i] for col in columns_names} 
                for i in filtered_df.index]

    def insert(self, new_entity):
        self._load_table()
        if self.__pandas_table is None:
            new_entity_dict = {key: [value] for key, value in new_entity.items()}
            self.__pandas_table = pd.DataFrame.from_dict(new_entity_dict)
            self._save_table()
            return
        new_entity_columns = list(new_entity.keys())
        current_columns = list(self.__pandas_table.columns)
        new_columns = [col for col in new_entity_columns if col not in current_columns]
        for col in new_columns:
            self.__pandas_table[col] = None
        self.__pandas_table.loc[len(self.__pandas_table), new_entity_columns] = [new_entity[c] for c in new_entity_columns]
        self._save_table()

    def delete(self, where: Union[dict, list[FilterCondition]]={}):
        self._load_table()
        if self.__pandas_table is None:
            return
        where_conditions = self._prepare_access_conditions(where)
        if not any(where_conditions):
            return
        self.__pandas_table = self.__pandas_table[~where_conditions]
        self._save_table()

    def update(self, update_vals, where: Union[dict, list[FilterCondition]]={}):
        self._load_table()
        if self.__pandas_table is None:
            return
        where_conditions = self._prepare_access_conditions(where)
        if not any(where_conditions):
            return
        filtered_view = self.__pandas_table[where_conditions]
        for key, value in update_vals.items():
            filtered_view[key] = value
        self._save_table()


class FileSystemQueueHandler(QueueHandler):

    def __init__(self, storage_folder: str, name, max_dequeue_count=20, invis_duration=60) -> None:
        super().__init__(name)
        self.__storage_folder = storage_folder
        self.max_dequeue_count = max_dequeue_count
        self.invis_duration = invis_duration
        self.__queue_path = os.path.join(storage_folder, _QUEUE_FOLDER, name)
        self.__opened_messages = []
        os.makedirs(os.path.join(self.__queue_path, "visible"), exist_ok=True)
        os.makedirs(os.path.join(self.__queue_path, "invisible"), exist_ok=True)
        
    def _update_visibility(self):
        invisible_folder = os.path.join(self.__queue_path, "invisible")
        all_invisible = os.listdir(invisible_folder)
        current_time = datetime.datetime.now()
        for invisible_msg in all_invisible:
            message_time = self._get_message_date(invisible_msg)
            if (current_time - message_time).seconds <= self.invis_duration:
                continue
            with open(os.path.join(invisible_folder, invisible_msg), "rb") as invisible_file:
                message_dict = pickle.load(invisible_file)
            os.remove(os.path.join(invisible_folder, invisible_msg))
            with open(os.path.join(self.__queue_path, "visible", invisible_msg), "wb") as visible_file:
                pickle.dump(message_dict, visible_file)

    def _get_message_date(self, message_name):
        fitting_msgs = glob.glob(os.path.join(self.__queue_path, "*", message_name))
        if not fitting_msgs:
            return None
        mod_time = os.path.getmtime(fitting_msgs[0])
        readable_time = datetime.datetime.fromtimestamp(mod_time)
        return readable_time

    def get(self) -> QueueMessage:
        self._update_visibility()
        visible_message_folder = os.path.join(self.__queue_path, "visible")
        all_messages = os.listdir(visible_message_folder)
        if not all_messages:
            return None
        sorted_messages = sorted(all_messages, key=lambda x: self._get_message_date(x))
        message_dict = None
        while message_dict is None:
            if not sorted_messages:
                return None
            next_message = sorted_messages.pop(0)
            message_path = os.path.join(visible_message_folder, next_message)
            with open(message_path, "rb") as message_file:
                message_dict = pickle.load(message_file)
            os.remove(message_path)
            message_dict["dequeue_count"] += 1
            if message_dict["dequeue_count"] >= self.max_dequeue_count:
                FileSystemQueueHandler(self.__storage_folder, self.name + "-poison").put(message_dict["message"])
                message_dict = None
        with open(os.path.join(self.__queue_path, "invisible", next_message), "wb") as invisible_file:
            pickle.dump(message_dict, invisible_file)
        self.__opened_messages.append(next_message)
        return QueueMessage(message_dict["message"], next_message, dequeue_count=message_dict["dequeue_count"])

    def ack_get(self, pop_receipt):
        if pop_receipt not in self.__opened_messages:
            return
        self.__opened_messages.remove(pop_receipt)
        fitting_msg = glob.glob(os.path.join(self.__queue_path, "*", pop_receipt))
        if not fitting_msg:
            return
        os.remove(fitting_msg[0])

    def put(self, item):
        self._update_visibility()
        new_id = uuid4().hex
        message_dict = {
            "message": item,
            "dequeue_count": 0,
        }
        with open(os.path.join(self.__queue_path, "visible", new_id), "wb") as message_file:
            pickle.dump(message_dict, message_file)

    def _get_length(self) -> int:
        self._update_visibility()
        visible_message_folder = os.path.join(self.__queue_path, "visible")
        len(os.listdir(visible_message_folder))


class FileSystemStorage(StorageSystem):

    def __init__(self, root_folder="."):
        self.root_folder = os.path.abspath(root_folder)

    @staticmethod
    def _prepare_file_folder_input(file, folder):
        file_info = super(FileSystemStorage, FileSystemStorage)._prepare_file_folder_input(file, folder)
        assert file_info.folder not in [_TABLE_FOLDER, _QUEUE_FOLDER], "Cannot access table or queue folders directly"
        return file_info

    def exists(self, file: Union[str, StorageFileInfo], folder=""):
        file_info = self._prepare_file_folder_input(file, folder)
        return os.path.isfile(os.path.join(self.root_folder, file_info.folder, file_info.name))
    
    def get_file_info(self, file: Union[str, StorageFileInfo], folder="") -> StorageFileFileInfo:
        file_info = self._prepare_file_folder_input(file, folder)
        file_path = os.path.join(self.root_folder, file_info.folder, file_info.name)
        last_modified = os.path.getmtime(file_path)
        file_size = os.path.getsize(file_path)
        return StorageFileFileInfo(last_modified, file_size)

    def read_file(self, file: Union[str, StorageFileInfo], folder="", is_text=False, encoding="utf8", encrypt=False):
        file_info = self._prepare_file_folder_input(file, folder)
        file_path = os.path.join(self.root_folder, file_info.folder, file_info.name)
        with open(file_path, "rb") as file_handler:
            file_contents = file_handler.read()
        if encrypt:
            file_contents = decrypt_bytes(file_contents)
        if is_text:
            file_contents = file_contents.decode(encoding=encoding)
        return file_contents

    def write_file(
            self,
            content: Union[str, bytes],
            file: Union[str, StorageFileInfo],
            folder="",
            encoding="utf8",
            encrypt=False
    ) -> StorageFileFileInfo:
        file_info = self._prepare_file_folder_input(file, folder)
        file_path = os.path.join(self.root_folder, file_info.folder, file_info.name)
        if isinstance(content, str):
            content = content.encode(encoding=encoding)
        if encrypt:
            content = encrypt_bytes(content)
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "wb") as file_handler:
            file_handler.write(content)
        return self.get_file_info(file_info)

    def backup_file(self, file, folder=""):
        file = self._prepare_file_folder_input(file, folder)
        dir_name, base_name = file.folder, file.name
        backup_path = os.path.join(self.root_folder, dir_name, ".backup")
        os.makedirs(backup_path, exist_ok=True)
        now_string = datetime.datetime.now().strftime("_%Y%m%d_%H%M%S")
        backup_file_name = now_string.join(os.path.splitext(base_name))
        backup_file_path = os.path.join(backup_path, backup_file_name)
        os.makedirs(os.path.dirname(backup_file_path), exist_ok=True)
        os.rename(
            os.path.join(self.root_folder, dir_name, base_name),
            backup_file_path
        )

    def pickle_file(self, py_obj, file, folder="", with_backup=True, encrypt=False) -> StorageFileFileInfo:
        file = self._prepare_file_folder_input(file, folder)
        folder, file_name = file.folder, file.name
        if not file_name.endswith(".pkl"):
            file_name += ".pkl"
        file_path = os.path.join(self.root_folder, folder, file_name)
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        if os.path.isfile(file_path) and with_backup:
            self.backup_file(file_path)
        pickle_bytes = pickle.dumps(py_obj)
        if encrypt:
            pickle_bytes = encrypt_bytes(pickle_bytes)
        with open(file_path, "wb") as pickle_file:
            pickle_file.write(pickle_bytes)
        return self.get_file_info(file)

    def unpickle_file(self, file, folder="", encrypt=False):
        file = self._prepare_file_folder_input(file, folder)
        folder, file_name = file.folder, file.name
        if not file_name.endswith(".pkl"):
            file_name += ".pkl"
        file_path = os.path.join(self.root_folder, folder, file_name)
        if not os.path.isfile(file_path):
            raise FileDoesNotExistError(file)
        with open(file_path, "rb") as pickle_file:
            if encrypt:
                pickle_file = BytesIO(decrypt_bytes(pickle_file.read()))
            python_obj = pickle.load(pickle_file)
        return python_obj

    def delete_file(self, file, folder="", with_backup=True):
        file = self._prepare_file_folder_input(file, folder)
        folder, file_name = file.folder, file.name
        file_path = os.path.join(self.root_folder, folder, file_name)
        if not os.path.isfile(file_path):
            return
        if with_backup:
            self.backup_file(file_path)
        else:
            os.remove(file_path)

    def list_files(self, folder):
        all_file_paths = glob.glob(os.path.join(self.root_folder, folder, "*.*"))
        path_tuples = [os.path.split(os.path.relpath(p, self.root_folder)) for p in all_file_paths]
        storage_files = [StorageFileInfo(*path_tuple) for path_tuple in path_tuples]
        for storage_file in storage_files:
            storage_file.info = self.get_file_info(storage_file)
        return storage_files

    def append_json_to_file(self, json_obj, file, folder=""):
        file = self._prepare_file_folder_input(file, folder)
        folder, file_name = file.folder, file.name
        file_path = os.path.join(self.root_folder, folder, file_name)
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "a", encoding="utf8") as json_file:
            json_file.write(json.dumps(json_obj) + "\n")

    def get_table_handler(self, table_name):
        table_root_folder = os.path.join(self.root_folder, _TABLE_FOLDER)
        return FileSystemTableHandler(
            self.root_folder, 
            table_name,
        )

    def get_queue_handler(self, queue_name, max_dequeue_count=20, invis_duration=60):
        queue_root_folder = os.path.join(self.root_folder)
        return FileSystemQueueHandler(
            queue_root_folder, 
            queue_name, 
            max_dequeue_count=max_dequeue_count, 
            invis_duration=invis_duration,
        )

    def read_append_json(self, file: Union[str, StorageFileInfo], folder=""):
        file = self._prepare_file_folder_input(file, folder)
        folder, file_name = file.folder, file.name
        file_path = os.path.join(self.root_folder, folder, file_name)
        if not os.path.isfile(file_path):
            raise FileDoesNotExistError(file)
        with open(file_path, "r", encoding="utf8") as json_file:
            append_json_lines = json_file.readlines()
        return [json.loads(line) for line in append_json_lines]

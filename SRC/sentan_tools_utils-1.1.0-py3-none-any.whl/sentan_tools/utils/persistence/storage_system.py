from abc import abstractmethod, ABC
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Iterable, Any, Optional, Union


class FilterConditionType(Enum):
    EQUAL = "EQUAL"
    NOT_EQUAL = "NOT_EQUAL"
    GREATER_THAN = "GREATER_THAN"
    GREATER_THAN_EQUAL = "GREATER_THAN_EQUAL"
    LESS_THAN = "LESS_THAN"
    LESS_THAN_EQUAL = "LESS_THAN_EQUAL"
    IN = "IN"
    NOT_IN = "NOT_IN"
    LIKE = "LIKE"
    NOT_LIKE = "NOT_LIKE"
    IS_NULL = "IS_NULL"
    IS_NOT_NULL = "IS_NOT_NULL"
    BETWEEN = "BETWEEN"
    NOT_BETWEEN = "NOT_BETWEEN"


@dataclass
class FilterCondition:
    type: FilterConditionType
    field: str
    value: Any


@dataclass
class QueueMessage:
    message: any
    pop_receipt: any
    dequeue_count: int = 0


@dataclass
class StorageFileFileInfo:
    last_modified: datetime
    size: int


@dataclass
class StorageFileInfo:
    folder: str
    name: str
    info: Optional[StorageFileFileInfo] = None


class FileInfoList:

    def __init__(self, file_info_iterable: Iterable[Any]):
        self._base_iterable = file_info_iterable

    def convert_file_info(self, file_info):
        if isinstance(file_info, StorageFileInfo):
            return file_info
        elif isinstance(file_info, (tuple, list)) and len(file_info) > 2:
            return StorageFileInfo(file_info[0], file_info[1])
        else:
            raise NotImplementedError(f"file info conversion not implemented for class {type(file_info).__name__}")

    def __iter__(self):

        class FileInfoListIter:
            def __init__(self, file_info_iterable: Iterable[Any], parent_obj):
                self.__file_info_iterable = iter(file_info_iterable)
                self.__parent_obj = parent_obj

            def __iter__(self):
                raise AssertionError("Can't call iter on this object")

            def __next__(self):
                next_item = next(self.__file_info_iterable)
                return self.__parent_obj.convert_file_info(next_item)

        return FileInfoListIter(self._base_iterable, self)


class TableHandler(ABC):

    def __init__(self, name) -> None:
        self.__name = name

    def get_name(self):
        return self.__name

    name = property(fget=get_name)

    @abstractmethod
    def get_table_entities(self, where={}) -> dict:
        pass

    @abstractmethod
    def insert(self, new_entity):
        pass

    @abstractmethod
    def delete(self, where={}):
        pass

    @abstractmethod
    def update(self, update_vals, where={}):
        pass


class QueueHandler(ABC):

    def __init__(self, name) -> None:
        self.__name = name

    def get_name(self):
        return self.__name

    name = property(fget=get_name)

    @abstractmethod
    def get(self) -> QueueMessage:
        pass

    def ack_get(self, pop_receipt):
        pass

    @abstractmethod
    def put(self, item):
        pass

    @abstractmethod
    def _get_length(self) -> int:
        pass

    def __len__(self):
        return self._get_length()


class StorageSystem(ABC):

    @staticmethod
    def _prepare_file_folder_input(file: Union[str, StorageFileInfo], folder: str):
        assert isinstance(file, (str, StorageFileInfo)), \
            "argument for file parameter has to be either string of StorageFileInfo"
        if isinstance(file, str):
            return StorageFileInfo(folder, file)
        return file

    @abstractmethod
    def backup_file(self, file: Union[str, StorageFileInfo], folder=""):
        pass

    @abstractmethod
    def exists(self, file: Union[str, StorageFileInfo], folder="") -> bool:
        pass

    @abstractmethod
    def pickle_file(self, py_obj, file: Union[str, StorageFileInfo], folder: str = "", with_backup=True, encrypt=False) -> StorageFileFileInfo:
        pass

    @abstractmethod
    def unpickle_file(self, file: Union[str, StorageFileInfo], folder="", encrypt=False):
        pass

    @abstractmethod
    def delete_file(self, file: Union[str, StorageFileInfo], folder="", with_backup=True):
        pass

    @abstractmethod
    def list_files(self, folder: str) -> FileInfoList:
        pass

    @abstractmethod
    def append_json_to_file(self, json_obj, file: Union[str, StorageFileInfo], folder=""):
        pass

    @abstractmethod
    def read_append_json(self, file: Union[str, StorageFileInfo], folder=""):
        pass

    @abstractmethod
    def get_file_info(self, file: Union[str, StorageFileInfo], folder="") -> StorageFileFileInfo:
        pass

    @abstractmethod
    def read_file(self, file: Union[str, StorageFileInfo], folder="", is_text=False, encoding="utf8", encrypt=False):
        pass

    @abstractmethod
    def write_file(
        self,
        content: Union[str, bytes],
        file: Union[str, StorageFileInfo],
        folder="",
        encoding="utf8",
        encrypt=False,
    ) -> StorageFileFileInfo:
        pass

    @abstractmethod
    def write_file(
            self,
            content: Union[str, bytes],
            file: Union[str, StorageFileInfo],
            folder="",
            encoding="utf8",
            encrypt=False
    ):
        pass

    @abstractmethod
    def get_table_handler(self, table_name: str) -> TableHandler:
        pass

    @abstractmethod
    def get_queue_handler(self, queue_name: str) -> QueueHandler:
        pass

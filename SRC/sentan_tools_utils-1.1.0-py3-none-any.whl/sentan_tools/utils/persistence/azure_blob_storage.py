import json
import os.path
import pickle
from datetime import datetime
from typing import Dict, List, Any, Union

from ..security.encryption import decrypt_bytes, encrypt_bytes
from .storage_system import FilterConditionType, QueueHandler, QueueMessage, StorageFileFileInfo, StorageSystem, TableHandler, FileInfoList, StorageFileInfo
from ._exceptions import FileDoesNotExistError


class AzureBlobFileInfoList(FileInfoList):

    def convert_file_info(self, file_info):
        return StorageFileInfo(file_info.container, file_info.name, info=StorageFileFileInfo(last_modified=file_info.last_modified, size=file_info.size))


class AzureStorageTableHandler(TableHandler):

    def __init__(self, connection_string, table_name) -> None:
        super().__init__(table_name)
        from azure.data.tables import TableServiceClient
        self.__connection_string = connection_string
        table_service_client = TableServiceClient.from_connection_string(conn_str=connection_string)
        table_service_client.create_table_if_not_exists(table_name=table_name)

    def _parse_filter_value(self, value):
        if isinstance(value, bool):
            return "true" if value else "false"
        elif isinstance(value, str):
            return f"'{value}'"
        elif isinstance(value, int):
            return str(value)
        elif isinstance(value, (list, tuple)):
            return "(" + ", ".join([self._parse_filter_value(v) for v in value]) + ")"
        raise ValueError(f"Unsupported type for value {value} in where_dict")

    def _get_query_filter(self, where_dict):
        where_str_items = []
        if isinstance(where_dict, dict):
            for key, val in where_dict.items():
                where_str_items.append(f"{key} eq {self._parse_filter_value(val)}")
        else:
            for filter_condition in where_dict:
                value_str = self._parse_filter_value(filter_condition.value)
                if filter_condition.type is FilterConditionType.EQUAL:
                    where_str_items.append(f"{filter_condition.field} eq {value_str}")
                elif filter_condition.type is FilterConditionType.NOT_EQUAL:
                    where_str_items.append(f"{filter_condition.field} ne {value_str}")
                elif filter_condition.type is FilterConditionType.GREATER_THAN:
                    where_str_items.append(f"{filter_condition.field} gt {value_str}")
                elif filter_condition.type is FilterConditionType.GREATER_THAN_EQUAL:
                    where_str_items.append(f"{filter_condition.field} ge {value_str}")
                elif filter_condition.type is FilterConditionType.LESS_THAN:
                    where_str_items.append(f"{filter_condition.field} lt {value_str}")
                elif filter_condition.type is FilterConditionType.LESS_THAN_EQUAL:
                    where_str_items.append(f"{filter_condition.field} le {value_str}")
                elif filter_condition.type is FilterConditionType.IS_NULL:
                    where_str_items.append(f"{filter_condition.field} eq null")
                elif filter_condition.type is FilterConditionType.IS_NOT_NULL:
                    where_str_items.append(f"{filter_condition.field} ne null")
                elif filter_condition.type is FilterConditionType.BETWEEN:
                    where_str_items.append(f"{filter_condition.field} ge {value_str[0]} and {filter_condition.field} le {value_str[1]}")
                elif filter_condition.type is FilterConditionType.NOT_BETWEEN:
                    where_str_items.append(f"{filter_condition.field} lt {value_str[0]} or {filter_condition.field} gt {value_str[1]}")
                else:
                    raise ValueError(f"Unsupported filter condition type {filter_condition.type} for Azure Table query")
        return " and ".join(where_str_items)

    def get_table_entities(self, where=None) -> List[Dict[str, Any]]:
        from azure.data.tables import TableClient
        where = where or {}
        query_filter = self._get_query_filter(where)
        table_client = TableClient.from_connection_string(conn_str=self.__connection_string, table_name=self.name)
        return [e for e in table_client.query_entities(query_filter)]

    def insert(self, new_entity):
        from azure.data.tables import TableClient
        table_client = TableClient.from_connection_string(conn_str=self.__connection_string, table_name=self.name)
        table_client.create_entity(entity=new_entity)

    def delete(self, where=None):
        from azure.data.tables import TableClient
        where = where or {}
        query_filter = self._get_query_filter(where)
        table_client = TableClient.from_connection_string(conn_str=self.__connection_string, table_name=self.name)
        entities_for_deletion = table_client.query_entities(query_filter)
        for entity in entities_for_deletion:
            table_client.delete_entity(partition_key=entity[u"PartitionKey"], row_key=entity[u"RowKey"])

    def update(self, update_vals, where=None):
        from azure.data.tables import TableClient
        where = where or {}
        query_filter = self._get_query_filter(where)
        table_client = TableClient.from_connection_string(conn_str=self.__connection_string, table_name=self.name)
        entities_for_update = table_client.query_entities(query_filter)
        for entity in entities_for_update:
            entity.update(update_vals)
            table_client.update_entity(entity)


class AzureStorageQueueHandler(QueueHandler):

    def __init__(self, connection_string, queue_name) -> None:
        super().__init__(queue_name)
        self.__connection_str = connection_string
        from azure.storage.queue import QueueServiceClient, TextBase64DecodePolicy, TextBase64EncodePolicy
        self._queue_client_options = {
            "message_encode_policy": TextBase64EncodePolicy(),
            "message_decode_policy": TextBase64DecodePolicy(),
        }
        queue_service_client = QueueServiceClient.from_connection_string(connection_string)
        try:
            queue_client = queue_service_client.create_queue(queue_name)
            print("Queue props:", queue_client.get_queue_properties())
        except:
            pass

    def get(self) -> QueueMessage:
        from azure.storage.queue import QueueClient
        queue_client = QueueClient.from_connection_string(
            self.__connection_str,
            self.name,
            **self._queue_client_options
        )
        next_message = queue_client.receive_message(visibility_timeout=3)
        if next_message:
            content = json.loads(next_message.get("content"))
            pop_receipt = (next_message.id, next_message.pop_receipt)
            return QueueMessage(message=content, pop_receipt=pop_receipt, dequeue_count=next_message.dequeue_count)
        return None

    def ack_get(self, pop_receipt):
        import azure
        from azure.storage.queue import QueueClient
        queue_client = QueueClient.from_connection_string(
            self.__connection_str,
            self.name,
            **self._queue_client_options
        )
        msg_id, receipt = pop_receipt
        try:
            queue_client.delete_message(msg_id, pop_receipt=receipt)
        except azure.core.exceptions.ResourceNotFoundError:
            pass

    def put(self, item):
        from azure.storage.queue import QueueClient
        queue_client = QueueClient.from_connection_string(
            self.__connection_str,
            self.name,
            **self._queue_client_options
        )
        queue_client.send_message(json.dumps(item))

    def _get_length(self) -> int:
        from azure.storage.queue import QueueClient
        queue_client = QueueClient.from_connection_string(
            self.__connection_str,
            self.name,
            **self._queue_client_options
        )
        props = queue_client.get_queue_properties()
        return props.approximate_message_count


class AzureBlobStorage(StorageSystem):

    def __init__(self, connection_string):
        self.connection_string = connection_string

    def backup_file(self, file, folder=""):
        file = self._prepare_file_folder_input(file, folder)
        from azure.storage.blob import BlobClient, StandardBlobTier
        container, file_name = file.folder, file.name
        now_string = datetime.now().strftime("_%Y%m%d_%H%M%S_%f")
        backup_file_name = now_string.join(os.path.splitext(file_name))
        backup_blob_client = BlobClient.from_connection_string(
            self.connection_string, container_name=container + "-backup", blob_name=backup_file_name)
        blob_client = BlobClient.from_connection_string(
            self.connection_string, container_name=container, blob_name=file_name)
        backup_blob_client.start_copy_from_url(blob_client.url)
        backup_blob_client.set_standard_blob_tier(StandardBlobTier.ARCHIVE)

    def exists(self, file: Union[str, StorageFileInfo], folder=""):
        from azure.storage.blob import BlobClient
        file_info = self._prepare_file_folder_input(file, folder)
        blob_client = BlobClient.from_connection_string(
            self.connection_string, container_name=file_info.folder, blob_name=file_info.name)
        return blob_client.exists()

    def read_file(self, file: Union[str, StorageFileInfo], folder="", is_text=False, encoding="utf8", encrypt=False):
        from azure.storage.blob import BlobClient
        file_info = self._prepare_file_folder_input(file, folder)
        blob_client = BlobClient.from_connection_string(
            self.connection_string, container_name=file_info.folder, blob_name=file_info.name)
        if not blob_client.exists():
            raise FileDoesNotExistError(file)
        download_stream = blob_client.download_blob()
        file_contents = download_stream.readall()
        if encrypt:
            file_contents = decrypt_bytes(file_contents)
        if is_text:
            file_contents = file_contents.decode(encoding=encoding)
        return file_contents

    def write_file(
            self,
            content: Union[str, bytes],
            file: Union[str, StorageFileInfo],
            folder="",
            encoding="utf8",
            encrypt=False,
    ) -> StorageFileFileInfo:
        from azure.storage.blob import BlobClient
        file_info = self._prepare_file_folder_input(file, folder)
        blob_client = BlobClient.from_connection_string(
            self.connection_string, container_name=file_info.folder, blob_name=file_info.name)
        if isinstance(content, str):
            content = content.encode(encoding=encoding)
        if encrypt:
            content = encrypt_bytes(content)
        info_dict = blob_client.upload_blob(content)
        return StorageFileFileInfo(last_modified=info_dict.get("last_modified"), size=len(content))

    def pickle_file(self, py_obj, file, folder="", with_backup=True, encrypt=False):
        file = self._prepare_file_folder_input(file, folder)
        folder, file_name = file.folder, file.name
        if not file_name.endswith(".pkl"):
            file_name += ".pkl"
        from azure.storage.blob import BlobClient
        blob_client = BlobClient.from_connection_string(
            self.connection_string, container_name=folder, blob_name=file_name)
        if blob_client.exists() and with_backup:
            self.backup_file(StorageFileInfo(folder, file_name))
        pickle_bytes = pickle.dumps(py_obj)
        if encrypt:
            pickle_bytes = encrypt_bytes(pickle_bytes)
        info_dict = blob_client.upload_blob(pickle_bytes, overwrite=True)
        return StorageFileFileInfo(last_modified=info_dict.get("last_modified"), size=len(pickle_bytes))

    def unpickle_file(self, file, folder="", encrypt=False):
        file = self._prepare_file_folder_input(file, folder)
        if not file.name.endswith(".pkl"):
            file.name += ".pkl"
        file_contents = self.read_file(file, encrypt=encrypt)
        return pickle.loads(file_contents)

    def delete_file(self, file, folder="default", with_backup=True):
        file = self._prepare_file_folder_input(file, folder)
        from azure.storage.blob import BlobClient
        blob_client = BlobClient.from_connection_string(
            self.connection_string, container_name=file.folder, blob_name=file.name)
        if not blob_client.exists():
            return
        if with_backup:
            self.backup_file(file)
        blob_client.delete_blob()

    def list_files(self, folder):
        from azure.storage.blob import BlobServiceClient
        blob_service_client = BlobServiceClient.from_connection_string(self.connection_string)
        container_client = blob_service_client.get_container_client(folder)
        return AzureBlobFileInfoList(container_client.list_blobs())

    def append_json_to_file(self, json_obj, file, folder=""):
        file = self._prepare_file_folder_input(file, folder)
        folder, file_name = file.folder, file.name
        from azure.storage.blob import BlobClient, ContentSettings
        blob_client = BlobClient.from_connection_string(
            self.connection_string, container_name=folder, blob_name=file_name)
        if not blob_client.exists():
            blob_client.create_append_blob(
                content_settings=ContentSettings(content_type="application/json", content_encoding="utf8")
            )
        append_string = json.dumps(json_obj) + "\n"
        blob_client.append_block(append_string)

    def get_file_info(self, file: Union[str, StorageFileInfo], folder="") -> StorageFileFileInfo:
        file = self._prepare_file_folder_input(file, folder)
        folder, file_name = file.folder, file.name
        from azure.storage.blob import BlobClient
        from azure.core.exceptions import ResourceNotFoundError
        blob_client = BlobClient.from_connection_string(
            self.connection_string, container_name=folder, blob_name=file_name)
        if not blob_client.exists():
            raise FileDoesNotExistError(file)
        try:
            blob_properties = blob_client.get_blob_properties()
        except ResourceNotFoundError:
            raise FileDoesNotExistError(file)
        return StorageFileFileInfo(last_modified=blob_properties.get("last_modified"), size=blob_properties.get("size"))

    def read_append_json(self, file, folder=""):
        file = self._prepare_file_folder_input(file, folder)
        folder, file_name = file.folder, file.name
        from azure.storage.blob import BlobClient
        blob_client = BlobClient.from_connection_string(
            self.connection_string, container_name=folder, blob_name=file_name)
        download_stream = blob_client.download_blob(encoding="utf8")
        append_json_txt = download_stream.readall()
        return [json.loads(json_txt) for json_txt in str(append_json_txt).split("\n") if json_txt]

    def get_table_handler(self, table_name):
        return AzureStorageTableHandler(self.connection_string, table_name)

    def get_queue_handler(self, queue_name):
        return AzureStorageQueueHandler(self.connection_string, queue_name)

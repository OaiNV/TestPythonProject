class FileDoesNotExistError(Exception):
    def __init__(self, file_info):
        super().__init__(f"File does not exist: {file_info.name} in {file_info.folder}")

    
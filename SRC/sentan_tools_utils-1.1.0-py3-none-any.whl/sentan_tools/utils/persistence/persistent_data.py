from copy import deepcopy

from . import FileDoesNotExistError
from .storage_system import StorageSystem, StorageFileInfo


class _ForceExist:
    pass

_FORCE_EXIST = _ForceExist()

class PersistentData:

    def __init__(self, storage_system: StorageSystem, folder, encrypt=False, enable_backups=False, always_save=False):
        self._folder = folder
        self._storage_system = storage_system
        self._file_mapping = {}
        self._data_store = {}
        self._file_last_mod = {}
        self._use_encryption = encrypt
        self._use_backups = enable_backups
        self._always_save = always_save
        self._last_saved_data = {}

    def __finfo(self, file_name):
        return StorageFileInfo(self._folder, file_name)
    
    def _load(self, item):
        file_name = self._file_mapping[item] if item in self._file_mapping else item
        try:
            file_info = self.__finfo(file_name + ".pkl")
            loaded_data = self._storage_system.unpickle_file(file_info, encrypt=self._use_encryption)
            loaded_data_props = self._storage_system.get_file_info(file_info)
            self._file_last_mod[item] = loaded_data_props.last_modified
            self._data_store[item] = loaded_data
            self._last_saved_data[item] = deepcopy(loaded_data) if not self._always_save else None
        except FileDoesNotExistError:
            pass
    
    def _save(self, item, saved_obj):
        file_name = self._file_mapping[item] if item in self._file_mapping else item
        file_info = self.__finfo(file_name + ".pkl")
        data_props = self._storage_system.pickle_file(saved_obj, file_info, with_backup=self._use_backups, encrypt=self._use_encryption)
        self._last_saved_data[item] = deepcopy(saved_obj) if not self._always_save else None
        self._file_last_mod[item] = data_props.last_modified
    
    def reload_if_modified(self, item):
        if item not in self._data_store:
            return
        file_name = self._file_mapping[item] if item in self._file_mapping else item
        file_info = self.__finfo(file_name + ".pkl")
        try:
            data_props = self._storage_system.get_file_info(file_info)
        except FileDoesNotExistError:
            return
        if data_props.last_modified > self._file_last_mod[item]:
            self.reload(item)
    
    def reload(self, item):
        if item not in self._data_store:
            return
        self._load(item)

    def get(self, key, default=_FORCE_EXIST, default_on_error=False):
        try:
            current_val = self[key]
        except KeyError:
            current_val = None
        except Exception as e:
            if default_on_error:
                current_val = None
            else:
                raise e
        if current_val is not None or isinstance(default, _ForceExist):
            return current_val
        self[key] = default
        return default

    def delete(self, key, with_backup=True):
        file_name = self._file_mapping[key] if key in self._file_mapping else key
        try:
            self._storage_system.delete_file(self.__finfo(file_name + ".pkl"), with_backup=with_backup)
            if key in self._data_store:
                self._data_store.pop(key)
            if key in self._last_saved_data:
                self._last_saved_data.pop(key)
            if key in self._file_last_mod:
                self._file_last_mod.pop(key)
        except FileDoesNotExistError:
            return None

    def register_file_mapping(self, item_name, file_name):
        self._file_mapping[item_name] = file_name

    def __getitem__(self, item):
        if item in self._data_store:
            self._load(item)
        else:
            self.reload_if_modified(item)
        return self._data_store[item]

    def __setitem__(self, key, value):
        assert value is not None
        self._data_store[key] = value
        has_changed = False
        if key in self._last_saved_data and not self._always_save:
            try:
                has_changed = value != self._last_saved_data[key]
            except AttributeError:
                has_changed = True
        if self._always_save or key not in self._last_saved_data or has_changed:
            self._save(key, value)

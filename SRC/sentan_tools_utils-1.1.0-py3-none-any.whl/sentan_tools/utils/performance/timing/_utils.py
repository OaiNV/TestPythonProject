class WPAMovingAverage:

    def __init__(self, width, warm_up=True):
        self.value = None
        self.width = float(width)
        self._warm_up_width = 2.0 if warm_up else width

    def __call__(self, next_val, *args, **kwargs):
        if self.value is None:
            self.value = next_val
        else:
            used_width = self.width
            if self._warm_up_width < self.width:
                used_width = self._warm_up_width
                self._warm_up_width += 1.0
            self.value = (1 - 1 / used_width) * self.value + (1 / used_width) * next_val
        return self.get()

    def get(self):
        return self.value


def seconds_to_time_string(seconds):
    if not isinstance(seconds, int):
        try:
            seconds = int(seconds)
        except:
            raise ValueError("only works with values that can be cast to int")
    sign = False
    if seconds < 0:
        sign = True
        seconds *= -1
    seconds = int(seconds)
    hours = seconds // 3600
    if hours > 999:
        return "999:59:59"
    if hours < -999:
        return "-999:59:59"
    seconds = seconds % 3600
    minutes = seconds // 60
    seconds = seconds % 60
    return "{}{:03d}:{:02d}:{:02d}".format("-" if sign else "", hours, minutes, seconds)

import time
from typing import Union, List

from ._utils import WPAMovingAverage
from .exceptions import StopWatchError


class StopWatch:

    def __init__(self, mva_weight: int, mva_warmup: bool = True):
        self._lap_ave = WPAMovingAverage(mva_weight, warm_up=mva_warmup)
        self._start_time = 0.0
        self._last_measure = 0.0
        self._pause_time = 0.0
        self._lap_pause_time = 0.0
        self._pause_start = -1.0
        self._stop_time = -1.0

    def start(self) -> None:
        self._start_time = time.perf_counter()
        self._last_measure = self._start_time

    def lap(self) -> float:
        if self._pause_start >= 0:
            raise StopWatchError("Cannot lap when stop watch is paused.")
        now = time.perf_counter()
        lap_ave = self._lap_ave(now - self._last_measure - self._lap_pause_time)
        self._lap_pause_time = 0
        self._last_measure = now
        return lap_ave

    def stop(self) -> float:
        self._stop_time = time.perf_counter()
        if self._pause_start > 0:
            self._pause_time += self._stop_time - self._pause_start
            self._pause_start = -1
        return self._stop_time - self._start_time - self._pause_time

    def get_time(self) -> float:
        if self._stop_time > 0:
            return self._stop_time - self._start_time - self._pause_time
        now = time.perf_counter()
        pause_time = self._pause_time
        if self._pause_start >= 0:
            pause_time += now - self._pause_start
        return now - self._start_time - pause_time

    def get_lap_average(self) -> float:
        la = self._lap_ave.get()
        if la is None:
            return 0.0
        return la

    def pause(self) -> None:
        if self._pause_start >= 0:
            return
        self._pause_start = time.perf_counter()

    def resume(self) -> None:
        if self._pause_start < 0:
            return
        self._pause_time += time.perf_counter() - self._pause_start
        self._lap_pause_time += time.perf_counter() - self._pause_start
        self._pause_start = -1


class MultiInstanceStopWatch:

    def __init__(self, mva_weight: int, mva_warmup: bool = True, num_instances: int = 1):
        self.__shared_lap_average = WPAMovingAverage(mva_weight, warm_up=mva_warmup)
        num_instances = max(num_instances, 1)
        self.__stop_watch_instances = [StopWatch(1, False) for _ in range(num_instances)]
        for stop_watch in self.__stop_watch_instances:
            stop_watch._lap_ave = self.__shared_lap_average

    def __len__(self):
        return len(self.__stop_watch_instances)

    def start(self, worker_idx: int = 0) -> None:
        assert worker_idx < len(self)
        if worker_idx < 0:
            map(lambda x: x.start(), self.__stop_watch_instances)
            return
        return self.__stop_watch_instances[worker_idx].start()

    def lap(self, worker_idx: int = 0) -> float:
        assert worker_idx < len(self)
        if worker_idx < 0:
            return sum(map(lambda x: x.lap(), self.__stop_watch_instances)) / len(self)
        return self.__stop_watch_instances[worker_idx].lap()

    def stop(self, worker_idx: int = 0) -> float:
        assert 0 <= worker_idx < len(self)
        if worker_idx < 0:
            return sum(map(lambda x: x.stop(), self.__stop_watch_instances)) / len(self)
        return self.__stop_watch_instances[worker_idx].stop()

    def get_time(self, worker_idx: int = -1) -> float:
        assert worker_idx < len(self)
        if worker_idx < 0:
            return sum([self.get_time(i) for i in range(len(self))]) / len(self)
        return self.__stop_watch_instances[worker_idx].get_time()

    def get_lap_average(self) -> float:
        return self.__shared_lap_average.get() or 0.0

    def pause(self, worker_idx: int = 0) -> None:
        assert worker_idx < len(self)
        if worker_idx < 0:
            map(lambda x: x.pause(), self.__stop_watch_instances)
            return
        return self.__stop_watch_instances[worker_idx].pause()

    def resume(self, worker_idx: int = 0) -> None:
        assert worker_idx < len(self)
        if worker_idx < 0:
            map(lambda x: x.resume(), self.__stop_watch_instances)
            return
        return self.__stop_watch_instances[worker_idx].resume()


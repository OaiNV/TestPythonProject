class StopWatchError(Exception):
    pass

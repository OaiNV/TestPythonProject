import time

from ._utils import WPAMovingAverage


class Timer:

    def __init__(self, mva_weight, mva_warmup=True):
        self._lap_ave = WPAMovingAverage(mva_weight, warm_up=mva_warmup)
        self._start_time = None
        self._last_measure = 0

    def start_recording(self):
        if self._start_time is not None:
            return
        self._start_time = time.perf_counter()

    def stop_recording(self):
        if self._start_time is None:
            return None
        timing = time.perf_counter() - self._start_time
        self._last_measure = timing
        self._lap_ave(timing)
        self._start_time = None
        return timing

    def get_last_time(self):
        return self._last_measure

    def get_average_time(self):
        la = self._lap_ave.get()
        return -1.0 if la is None else la

    def __enter__(self):
        self.start_recording()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop_recording()
        return False


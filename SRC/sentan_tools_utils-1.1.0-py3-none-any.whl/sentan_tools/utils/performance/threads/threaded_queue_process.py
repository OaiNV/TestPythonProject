from typing import List, Any

from .threaded_process import ThreadedProcess


class WorkQueue:

    def __init__(self, initial_items=()):
        self.__items = list(initial_items)

    def get(self):
        if not len(self):
            return None
        return self.__items.pop(0)

    def get_batch(self, batch_size):
        if not len(self):
            return None
        next_batch = self.__items[:batch_size]
        if len(self.__items) <= batch_size:
            self.__items = []
        else:
            self.__items = self.__items[batch_size:]
        return next_batch

    def put_one(self, item):
        self.__items.append(item)

    def put_many(self, items):
        self.__items.extend(items)

    def __len__(self):
        return len(self.__items)


class ThreadedQueueProcess(ThreadedProcess):

    def __init__(self, items, process_func, batch_size=1, num_workers=1):
        super().__init__(num_workers=num_workers)
        self.__work_queue = WorkQueue(initial_items=items)
        self.__result_queue = WorkQueue()
        self._process_func = process_func
        self.batch_size = batch_size

    def process_items(self, items: List[Any]) -> List[Any]:
        return self._process_func(items)

    def run_loop(self, worker_idx: int = 0) -> bool:
        with self._flex_lock("work_queue"):
            next_items = self.__work_queue.get_batch(max(1, self.batch_size))
        if next_items is None:
            return False
        try:
            next_results = self.process_items(next_items)
            with self._flex_lock("result_queue"):
                self.__result_queue.put_many(next_results)
            return True
        except:
            with self._flex_lock("work_queue"):
                self.__work_queue.put_many(next_items)
        return False

from abc import ABC, abstractmethod
from threading import Thread, Semaphore, RLock, Lock
from time import sleep
from typing import Any, List, Optional, Tuple

from .thread_safe_types import ThreadSafeMultiInstanceStopWatch as StopWatch


class StopThreadedProcess(Exception):
    pass


class ThreadedProcessException(Exception):
    pass


class ExecutionState:
    """プロセスの実行状況に関する変数を束ねます"""

    def __init__(self):
        self.is_running = False
        self.is_paused = False
        self.is_stopped = False
        self.has_run = False
        self.crashed = False


class ThreadSecure(ABC):
    """スレッドを安全に運用できるための機能を提供します。"""

    def __init__(self):
        self.__flex_locks_lock = Lock()
        self.__flex_locks = {}

    def _flex_lock(self, lock_name: str) -> RLock:
        """指定した名前のロックを取得する

        Parameters
        ----------
        lock_name
            ロックの名前

        Returns
        -------
        RLock
            ロック
        """
        with self.__flex_locks_lock:
            if lock_name not in self.__flex_locks:
                self.__flex_locks[lock_name] = RLock()
            return self.__flex_locks[lock_name]

    @staticmethod
    def safely_run_with_locks(
            function_call, locks, re_raise=False
    ) -> Tuple[bool, Any]:
        """ロックを守りながら安全に指定の関数を実行する。

        Parameters
        ----------
        function_call
            実行する関数
        locks
            獲得したロック
        re_raise
            エラーを外に出すかどうか

        Returns
        -------
        bool
            実行が成功した場合true、エラーが発生した場合False
        Any
            関数の戻り値
        """
        try:
            return_val = function_call()
        except Exception as e:
            if re_raise:
                raise e
            else:
                return False, None
        finally:
            for lock in locks:
                lock.release()
        return True, return_val


class WorkerLock:
    """ワーカーの実行を制御するためのロック

    このロックを利用するとblockingをしなくてもwithが使えます。

    >>>sem = Semaphore()
    >>>worker_lock = WorkerLock(sem)
    >>>if not worker_lock.is_acquired():
    >>>    return
    >>>with worker_lock:
    >>>    # do stuff

    Parameters
    ----------
    semaphore
        ラッピングされる本当のロック
    blocking
        取得する時に使用されるblocking
    timeout
        取得する時に使用されるタイムアウト
    """

    def __init__(self, semaphore: Semaphore, blocking=True, timeout=5):
        self._semaphor = semaphore
        self._acquired = semaphore.acquire(blocking=blocking, timeout=timeout)

    def is_acquired(self) -> bool:
        """ロックの獲得が成功したか確認する。

        Returns
        -------
        bool
           ロックの獲得が成功したかどうか

        """
        return self._acquired

    def release(self) -> None:
        """ロックが獲得された場合にロックを開放する。"""
        if not self._acquired:
            return
        self._semaphor.release()
        self._acquired = False
        sleep(0.001)

    def __enter__(self):
        if not self._acquired:
            raise ThreadedProcessException("Can't enter unaquired lock")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()


class Worker:
    """スレッドのワーカーの情報を束ねます。

    Attributes
    ----------
    worker_index : int
        ワーカーのID

    Parameters
    ----------
    w_thread
        ワーカーのスレッド
    w_index
        ワーカーのID
    started
        ワーカーのスレッドが既に開始されたかどうか
    """

    def __init__(self, w_thread: Thread, w_index: int, started=False):
        self._thread = w_thread
        self.worker_index = w_index
        self._started = started
        self._worker_lock = Semaphore()

    def start(self) -> bool:
        """ワーカーがまだ開始されていない場合は開始する。

        Returns
        -------
        bool
            開始されたかどうか
        """
        if self._started:
            return False
        self._thread.start()
        self._started = True
        return True

    def is_alive(self) -> bool:
        """ワーカーが生きているかどうかを確認する。

        Returns
        -------
        bool
            生きているかどうか
        """
        return self._thread is not None and self._thread.is_alive()

    def acquire_lock(self) -> WorkerLock:
        """ワーカーのロックを獲得する。

        Returns
        -------
        WorkerLock
            ワーカーのロック
        """
        return WorkerLock(self._worker_lock)


class WorkerPool:
    """ワーカーの数個を管理する。"""

    def __init__(self):
        self._workers = {}

    def add_worker(self, worker: Worker) -> None:
        """新しいワーカーを追加する。

        Parameters
        ----------
        worker
            追加されるワーカー
        """
        w_id = worker.worker_index
        if id(worker) in [id(w) for w in self._workers.values()]:
            raise ThreadedProcessException("Worker was added twice to worker pool")
        if w_id in self._workers:
            raise ThreadedProcessException(
                "Worker for id {} is already registered".format(w_id)
            )
        self._workers[w_id] = worker

    def start_workers(self) -> None:
        """まだ開始されていないワーカーを開始する。"""
        for worker in self._workers.values():
            worker.start()

    def remove_dead_workers(self) -> List[int]:
        """死んでいたワーカーを削除する。

        Returns
        -------
        List[int]
            削除されていたワーカーのIDの配列
        """
        dead_worker_idx_list = [
            w.worker_index for w_id, w in self._workers.items() if not w.is_alive()
        ]
        self._workers = {w_id: w for w_id, w in self._workers.items() if w.is_alive()}
        return dead_worker_idx_list

    def has_alive_workers(self):
        """生きているワーカーが存在するか確認する。

        Returns
        -------
        bool
            生きているワーカーが存在するかどうか
        """
        return any([w.is_alive() for w in self._workers.values()])

    def acquire_worker_lock(self, worker_id: int) -> WorkerLock:
        """対象ワーカーのロックを獲得する。

        Parameters
        ----------
        worker_id
            対象ワーカーのID

        Returns
        -------
        WorkerLock
            ワーカーのロック
        """
        return self._workers[worker_id].acquire_lock()

    def acquire_all_locks(self, caller_id: int = None) -> Optional[List[WorkerLock]]:
        """すべてのワーカーのロックを獲得する。

        ワーカーが呼び出すとそのワーカーのロックは無視される。

        Parameters
        ----------
        caller_id
            呼び出すワーカーのID

        Returns
        -------
        Optional[List[WorkerLock]]
            獲得したロックの配列。（失敗する場合はNoneを返す）
        """
        locks = []
        for worker_id in self._workers.keys():
            if worker_id == caller_id:
                continue
            next_lock = self.acquire_worker_lock(worker_id)
            locks.append(next_lock)
            if not next_lock.is_acquired():
                break

        if not locks:
            return locks

        if any([not l.is_acquired() for l in locks]):
            map(lambda x: x.release(), locks)
            return None
        return locks


class ThreadedProcess(ThreadSecure):
    """あるプロセスを安全にスレッドで実施できるためのクラス。

    複数のワーカーを指定するとすべてのワーカーが同じ処理を実施します。

    Attributes
    ----------
    error_msg
        スレッド内にエラーが発生する場合は、ここにエラーメッセージが入る
    timer
        処理の実施時間を図るためのタイマー

    Parameters
    ----------
    num_workers
        ワーカー（並行スレッド）の数
    """

    def __init__(self, num_workers: int = 1):
        super(ThreadedProcess, self).__init__()
        self._num_workers = max(1, num_workers)
        self._worker_pool = WorkerPool()
        self._exec_state = ExecutionState()
        self._subthreads = []
        self.error_msg = None
        self.timer = StopWatch(10, num_workers=self._num_workers)
        self._has_run = False

    def start(self) -> bool:
        """プロセスを開始する。

        Returns
        -------
        bool
            開始が成功したかどうか
        """
        if self._exec_state.crashed or self._exec_state.is_running:
            return False
        self._exec_state.has_run = False
        self._exec_state.is_running = True
        self._exec_state.is_paused = False
        self._exec_state.is_stopped = False
        self._worker_pool.remove_dead_workers()
        for i in range(self._num_workers):
            new_worker = Worker(
                Thread(target=lambda: self._run_worker(i), daemon=True), i
            )
            self._worker_pool.add_worker(new_worker)
        self._worker_pool.start_workers()
        return True

    def revive(self) -> None:
        """死んだワーカーを蘇る。"""
        if not self._exec_state.is_running:
            return
        missing_worker_ids = self._worker_pool.remove_dead_workers()
        for worker_id in missing_worker_ids:
            new_worker = Worker(
                Thread(target=lambda: self._run_worker(worker_id), daemon=True),
                worker_id,
            )
            self._worker_pool.add_worker(new_worker)
        self._worker_pool.start_workers()

    def is_alive(self) -> bool:
        """プロセスはまだ生きているか確認する。

        Returns
        -------
        bool
            まだ生きているかどうか
        """
        return self._worker_pool.has_alive_workers()

    def _stop(self) -> None:
        self._exec_state.is_running = False
        self.stop_subthreads()

    def stop(self) -> None:
        """プロセスを停止する。"""
        if self._exec_state.is_running:
            self._exec_state.is_stopped = True
        self._stop()

    def pause(self) -> None:
        """プロセスを一時的に中止する。"""
        self._exec_state.is_paused = True

    def cont(self) -> None:
        """プロセスを一時的に中止された場合再開する。"""
        self._exec_state.is_paused = False

    @abstractmethod
    def run_loop(self, worker_idx: int = 0) -> bool:
        return False

    def _initialize(self):
        pass

    def _finalize(self):
        pass

    def on_crash(self, exc: Exception, worker_idx: int = 0, **_):
        """スレッド内にエラーが発生する場合はこの関数が呼び出される。

        Parameters
        ----------
        exc
            エラーのインスタンス
        worker_idx
            ワーカーのID

        """
        self.error_msg = "Error in worker thread " + str(worker_idx) + ": " + str(exc)
        self._exec_state.crashed = True
        self.stop()

    def _run_worker_loop(self, worker_idx):
        if self._exec_state.is_paused:
            sleep(0.1)
            return
        worker_lock = self._worker_pool.acquire_worker_lock(worker_idx)
        if not worker_lock.is_acquired():
            return
        with worker_lock:
            self.timer.resume(worker_idx=worker_idx)
            success = self.run_loop(worker_idx)
            self.timer.lap(worker_idx=worker_idx)
            self.timer.pause(worker_idx=worker_idx)
            if success:
                self._has_run = True
            else:
                sleep(0.0001)

    def _run_worker(self, worker_idx):
        try:
            self._initialize()
            self.timer.start(worker_idx=worker_idx)
            while self._exec_state.is_running:
                self._run_worker_loop(worker_idx)
        except StopThreadedProcess:
            self._stop()
        except Exception as e:
            self.on_crash(e, worker_idx=worker_idx)
        finally:
            self.timer.stop(worker_idx=worker_idx)
            self._finalize()

    def get_past_time(self) -> float:
        """実施された時間の合計を取得する。

        Returns
        -------
        float
            実施の時間の秒数
        """
        return self.timer.get_time()

    def get_average_iteration_time(self) -> float:
        """ループイテレーションの平均実行時間を取得する。

        Returns
        -------
        float
            平均実行時間の秒数
        """
        return self.timer.get_lap_average()

    def has_run(self) -> bool:
        """処理を実施したことがあるか確認する。

        Returns
        -------
        bool
            処理を実施したことがあるかどうか
        """
        return self._has_run

    def has_crashed(self) -> bool:
        """スレッドでエラーが発生したか確認する。

        Returns
        -------
        bool
            スレッドでエラーが発生したかどうか
        """
        return self._exec_state.crashed

    def was_stopped(self) -> bool:
        """プロセスが停止されたか確認する。

        Returns
        -------
        bool
            プロセスが停止されたかどうか
        """
        return self._exec_state.is_stopped

    def __del__(self):
        self.stop()

    def register_subthread(self, subthread: "ThreadedProcess"):
        """子プロセスを登録する。

        Parameters
        ----------
        subthread
            子プロセス

        """
        if isinstance(subthread, ThreadedProcess) and not subthread in self._subthreads:
            self._subthreads.append(subthread)

    def has_live_subthreads(self):
        """まだ生きている子スレッドがあるか確認する。

        Returns
        -------
        bool
            まだ生きている子スレッドがあるかどうか
        """
        return any([st.is_alive() for st in self._subthreads])

    def start_subthreads(self):
        """子スレッドを全て開始する。"""
        for st in self._subthreads:
            st.start()

    def stop_subthreads(self):
        """子スレッドを全て停止する。"""
        for st in self._subthreads:
            st.stop()

    def synched(
            self,
            function_call: callable,
            worker_idx: int = -1,
            re_raise=False,
    ) -> Tuple[bool, Any]:
        """スレッドを待たせて指定の関数を実行する。

        Parameters
        ----------
        function_call
            実行したい関数
        worker_idx
            実行するワーカーのID（外部から実行する場合はー１）
        re_raise
            関数の実行中に発生するエラーを出すかどうか

        Returns
        -------
        bool
            実行が成功したかどうか
        Any
            実行した関数の戻り値
        """
        if not self._flex_lock("__global_synch_lock").acquire(blocking=False):
            return False, None

        worker_locks = self._worker_pool.acquire_all_locks(caller_id=worker_idx)
        if worker_locks is None:
            return False, None

        all_acquired_locks = worker_locks + [self._flex_lock("__global_synch_lock")]
        return self.safely_run_with_locks(
            function_call, all_acquired_locks, re_raise=re_raise
        )

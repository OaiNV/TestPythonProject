import inspect
from functools import partial
from threading import Lock

from ..timing import StopWatch, MultiInstanceStopWatch, Timer


class ThreadSafeVariable:

    def __init__(self, lock=None):
        self.__lock = lock or Lock()

    def __set_name__(self, owner, name):
        self.public_name = name
        self.private_name = '_thread_safe_' + name

    def __get__(self, obj, objtype=None):
        with self.__lock:
            value = getattr(obj, self.private_name)
            return value

    def __set__(self, obj, value):
        with self.__lock:
            setattr(obj, self.private_name, value)


def _make_thread_safe_method(target_method, lock=None):
    def wrapper(*args, **kwargs):
        first_arg = args[0] if len(args) > 0 else None
        if first_arg is None:
            return target_method(*args, **kwargs)
        used_lock = lock
        if used_lock is None:
            if not hasattr(first_arg, "_thread_safe_lock"):
                setattr(first_arg, "_thread_safe_lock", Lock())
            used_lock = getattr(first_arg, "_thread_safe_lock")
        with used_lock:
            return target_method(*args, **kwargs)

    return wrapper


def _make_thread_safe_function(target_method, lock):
    def wrapper(*args, **kwargs):
        with lock:
            return target_method(*args, **kwargs)

    return wrapper


def _make_thread_safe_class(unsafe_type, fixed_lock=None):
    for name, m in inspect.getmembers(
            unsafe_type, predicate=lambda x: inspect.isfunction(x) or inspect.ismethod(x)):
        if name.startswith('_'):
            continue
        if inspect.ismethod(m):
            new_m = _make_thread_safe_method(m, lock=fixed_lock)
            setattr(unsafe_type, name, new_m)
        else:
            class_lock = fixed_lock
            if class_lock is None:
                if not hasattr(unsafe_type, "_thread_safe_class_lock"):
                    setattr(unsafe_type, "_thread_safe_class_lock", Lock())
                class_lock = getattr(unsafe_type, "_thread_safe_class_lock")
            new_m = _make_thread_safe_function(m, class_lock)
            setattr(unsafe_type, name, new_m)
    return unsafe_type


def make_thread_safe(target, fixed_lock=None):
    if isinstance(target, type(Lock())):
        return partial(make_thread_safe, fixed_lock=target)
    if isinstance(target, type):
        return _make_thread_safe_class(target, fixed_lock=fixed_lock)
    elif inspect.ismethod(target):
        return _make_thread_safe_method(target, lock=fixed_lock)
    elif inspect.isfunction(target):
        if fixed_lock is None:
            raise ValueError("When applied to functions, a lock has to be given.")
        return _make_thread_safe_function(target, fixed_lock)
    else:
        raise NotImplementedError(f"Decorator only defined for classes, functions "
                                  f"and class methods not for {type(target).__name__}")


ThreadSafeStopWatch = make_thread_safe(StopWatch)
ThreadSafeMultiInstanceStopWatch = make_thread_safe(MultiInstanceStopWatch)
ThreadSafeTimer = make_thread_safe(Timer)

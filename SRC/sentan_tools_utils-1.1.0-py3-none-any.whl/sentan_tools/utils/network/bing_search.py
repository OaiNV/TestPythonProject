import requests
import dataclasses
from enum import Enum
from typing import Optional
from datetime import datetime
import dateutil.parser as date_parsing


class SearchFreshness(Enum):
    NONE = "None"
    DAY = "Day"
    WEEK = "Week"
    MONTH = "Month"
    DATE = "Date"
    DURATION = "Duration"


@dataclasses.dataclass
class BingSearchOptions:
    freshness: SearchFreshness = SearchFreshness.NONE
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    num_results: int = 20
    page_idx: int = 0


@dataclasses.dataclass
class BingImageData:
    content_url: str
    width: int
    height: int

    def to_dict(self):
        return {
            "content_url": self.content_url,
            "width": self.width,
            "height": self.height,
        }


class BingSearchResult:

    def __init__(self, url, name, publish_date) -> None:
        self.name = name
        self.url = url
        self.publish_date = publish_date

    def to_dict(self):
        return {
            "url": self.url,
            "name": self.name,
            "publish_date": self.publish_date.isoformat(),
        }


class BingNewsSearchResult(BingSearchResult):
    def __init__(self, url, name, publish_date, image=None, description="", category="") -> None:
        super().__init__(url, name, publish_date)
        self.image = image or {}
        self.description = description
        self.category = category

    @staticmethod
    def from_search_result(search_result: dict):
        publish_date = date_parsing.parse(search_result["datePublished"])
        image = search_result.get("image", {})
        image_data = {}
        for image_name, image_dict in image.items():
            image_data[image_name] = BingImageData(content_url=image_dict["contentUrl"], width=image_dict["width"], height=image_dict["height"])
        return BingNewsSearchResult(
            search_result["url"], 
            search_result["name"], 
            publish_date, 
            image=image_data, 
            description=search_result["description"],
            category=search_result.get("category", "")
        )

    def to_dict(self):
        return {
            **super().to_dict(),
            "image": {name: image.to_dict() for name, image in self.image.items()},
            "description": self.description,
            "category": self.category,
        }


class BingWebSearchResult(BingSearchResult):
    def __init__(self, url, name, snippet, publish_date) -> None:
        super().__init__(url, name, publish_date)
        self.snippet = snippet

    @staticmethod
    def from_search_result(search_result: dict):
        publish_date = date_parsing.parse(search_result["datePublished"])
        # publish_date = datetime.strptime(search_result["datePublished"], "%Y-%m-%dT%H:%M:%S.%Z")
        return BingWebSearchResult(search_result["url"], search_result["name"], search_result["snippet"], publish_date)

    def to_dict(self):
        return {
            **super().to_dict(),
            "snippet": self.snippet,
        }
        

class BingSearchError(Exception):

    def __init__(self, response: requests.Response):
        super().__init__(f"Bing search request returned code {response.status_code}")


def search_bing_news(api_endpoint, api_key, search_query=None, category=None, search_options=None, language=None):
    if not search_options:
        search_options = BingSearchOptions()
    headers = {"Ocp-Apim-Subscription-Key": api_key}
    freshness_param = None
    if search_options.freshness in [SearchFreshness.DAY, SearchFreshness.WEEK, SearchFreshness.MONTH]:
        freshness_param = search_options.freshness.value
    elif search_options.freshness is SearchFreshness.DATE:
        freshness_param = search_options.start_date.strftime('%Y-%m-%d')
    elif search_options.freshness is SearchFreshness.DURATION:
        freshness_param = f"{search_options.start_date.strftime('%Y-%m-%d')}..{search_options.end_date.strftime('%Y-%m-%d')}"
    params = {
        "count": search_options.num_results,
        "offset": search_options.page_idx * search_options.num_results,
        "textDecorations": "true",
        "textFormat": "HTML",
    }
    if search_query:
        params["q"] = search_query
    if freshness_param:
        params["freshness"] = freshness_param
    if language:
        params["mkt"] = language
    if category:
        params["category"] = category
    api_endpoint += "news" if api_endpoint[-1] == "/" else "/news"
    if search_query:
        api_endpoint += "/search"
    response: requests.Response = requests.get(api_endpoint, params=params, headers=headers)
    if not response.ok:
        raise BingSearchError(response)
    search_results = response.json()
    offset = search_options.page_idx * search_options.num_results
    total_matches = search_results["totalEstimatedMatches"]
    current_search_results = [BingNewsSearchResult.from_search_result(result) for result in search_results["value"]]
    possible_matches = max(total_matches - offset, 0)
    print(total_matches, offset, possible_matches)
    return total_matches, current_search_results[:possible_matches]


def search_bing(search_query, api_endpoint, api_key, search_options=None, language=None):
    if not search_options:
        search_options = BingSearchOptions()
    headers = {"Ocp-Apim-Subscription-Key": api_key}
    freshness_param = None
    if search_options.freshness in [SearchFreshness.DAY, SearchFreshness.WEEK, SearchFreshness.MONTH]:
        freshness_param = search_options.freshness.value
    elif search_options.freshness is SearchFreshness.DATE:
        freshness_param = search_options.start_date.strftime('%Y-%m-%d')
    elif search_options.freshness is SearchFreshness.DURATION:
        freshness_param = f"{search_options.start_date.strftime('%Y-%m-%d')}..{search_options.end_date.strftime('%Y-%m-%d')}"
    params = {
        "q": search_query,
        "count": search_options.num_results,
        "offset": search_options.page_idx * search_options.num_results,
        "textDecorations": "true",
        "textFormat": "HTML",
    }
    if freshness_param:
        params["freshness"] = freshness_param
    if language:
        params["mkt"] = language
    api_endpoint += "search" if api_endpoint[-1] == "/" else "/search"
    print(params)
    response: requests.Response = requests.get(api_endpoint, params=params, headers=headers)
    if not response.ok:
        raise BingSearchError(response)
    search_results = response.json()
    offset = search_options.page_idx * search_options.num_results
    # print(search_results)
    if "webPages" not in search_results:
        return 0, []
    total_matches = search_results["webPages"]["totalEstimatedMatches"]
    current_search_results = [BingWebSearchResult.from_search_result(result) for result in search_results["webPages"]["value"]]
    possible_matches = max(total_matches - offset, 0)
    return total_matches, current_search_results[:possible_matches]

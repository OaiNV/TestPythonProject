from functools import reduce
from typing import Iterable, Any, Callable, Tuple


def combine(combination_func: Callable[[Any, Any], Any], *combined_items: Iterable[Any]):
    if not combined_items:
        raise ValueError("Second parameter missing.")
    if len(combined_items) == 1:
        combined_items = combined_items[0]
    if len(combined_items) <= 1:
        raise ValueError(f"Cannot combine {len(combined_items)} items.")
    first_item = combined_items[0]
    return reduce(combination_func, combined_items[1:], first_item)


def add_up(*items):
    if not items:
        raise ValueError("No items given")
    if len(items) == 1:
        items = items[0]
    return reduce(lambda a, b: a + b, items)
